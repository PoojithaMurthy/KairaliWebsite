#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Opening the site directly instead..."
  open "site/index.html"; exit 0
fi
if [ ! -d "src/img/kairali" ]; then
  echo "Saving Kairali's photos locally (first run only)..."
  node build.js >/dev/null && node fetch-images.js
fi
node build.js
(sleep 1; open "http://localhost:5173") &
echo "Kairali preview running at http://localhost:5173 - press Ctrl+C to stop."
node serve.js 5173
