// Static site generator for the Kairali sample website.
//   node build.js   ->  writes ./site/*.html and copies assets
// No dependencies. Navigation + content live in content/site.js.

const fs = require("fs");
const path = require("path");
const { sections, pages } = require("./content/site");
const branches = require("./content/branches");
const { brands, products } = require("./content/products");
const details = require("./content/product-details");
const bigOf = (u) => u.replace(/-\d+x\d+(?=\.\w+$)/, "");
products.forEach((p) => { const d = details[p.id]; if (d) { Object.assign(p, { long: d.long, features: d.features, uses: d.uses, src: d.src, big: d.big || bigOf(p.img) }); p.draft = false; } else { p.big = bigOf(p.img); } });

const OUT = path.join(__dirname, "site");
const SITE = { name: "Kairali", full: "Kairali Agriculture Multi State Co-operative Society Ltd.", short: "Agriculture MSCS Ltd." };

/* ---------------------------------------------------------------- icons */
const ICONS = {
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"/><path d="M2 21c0-3 1.9-5.4 5.1-6C9.500 14.500 12 13 13 12"/>',
  sprout: '<path d="M12 22V12"/><path d="M12 12C12 8 9 6 4 6c0 4 2 6 8 6z"/><path d="M12 14c0-3.500 2.500-6 8-6 0 4-2.500 6-8 6z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.900 4.900l1.400 1.400M17.700 17.700l1.400 1.400M2 12h2M20 12h2M4.900 19.100l1.400-1.400M17.700 6.300l1.400-1.400"/>',
  jar: '<path d="M8 3h8v3H8z"/><path d="M6 6h12v13a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2z"/><path d="M6 11h12M6 16h12"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2c3 3 4.500 6.500 4.500 10S15 19 12 22c-3-3-4.500-6.500-4.500-10S9 5 12 2z"/>',
  camera: '<path d="M3 8a2 2 0 0 1 2-2h2l2-2h6l2 2h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="4"/>',
  users: '<circle cx="9" cy="8" r="3.500"/><path d="M2.500 20a6.500 6.500 0 0 1 13 0"/><circle cx="17" cy="9" r="2.500"/><path d="M17 14a5 5 0 0 1 4.500 5"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  pin: '<path d="M12 21s7-6.200 7-11a7 7 0 1 0-14 0c0 4.800 7 11 7 11z"/><circle cx="12" cy="10" r="2.500"/>',
  map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
  wheat: '<path d="M12 22V6"/><path d="M12 8c-3 0-4.500-2-4.500-4.500C10.500 3.500 12 5.500 12 8zM12 8c3 0 4.500-2 4.500-4.500C13.500 3.500 12 5.500 12 8zM12 13c-3 0-4.500-2-4.500-4.500 3 0 4.500 2 4.500 4.500zM12 13c3 0 4.500-2 4.500-4.500-3 0-4.500 2-4.500 4.500zM12 18c-3 0-4.500-2-4.500-4.500 3 0 4.500 2 4.500 4.500zM12 18c3 0 4.500-2 4.500-4.500-3 0-4.500 2-4.500 4.500z"/>',
  coins: '<circle cx="9" cy="9" r="6"/><path d="M18.100 10.400A6 6 0 1 1 10.300 18"/><path d="M7 6.500h2v5"/>',
  tree: '<circle cx="12" cy="9" r="6.500"/><path d="M12 22v-8M12 17l-3-3M12 15l3-3"/>',
  book: '<path d="M3 5h7a3 3 0 0 1 3 3v13a2 2 0 0 0-2-2H3z"/><path d="M21 5h-7a3 3 0 0 0-3 3"/><path d="M21 5v14h-8"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M8.500 12l2.500 2.500 4.500-5"/>',
  hand: '<path d="M8 13V5.500a1.500 1.500 0 0 1 3 0V11"/><path d="M11 10.500V4a1.500 1.500 0 0 1 3 0v7"/><path d="M14 10V6a1.500 1.500 0 0 1 3 0v8c0 4-2.500 7-6 7-3 0-4.500-2-6-5l-1-2a1.500 1.500 0 0 1 2.500-1.500L8 15"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  route: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h7a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h7"/>',
  cow: '<path d="M5 8L3 4.500M19 8l2-3.500"/><path d="M5 8h14v6a5 5 0 0 1-5 5h-4a5 5 0 0 1-5-5z"/><circle cx="9.500" cy="12" r=".9"/><circle cx="14.500" cy="12" r=".9"/><path d="M10 16h4"/>',
  egg: '<path d="M12 3c4 0 7 6 7 11a7 7 0 0 1-14 0c0-5 3-11 7-11z"/>',
  fish: '<path d="M3 12c3-5 9-6 13-3l5-3v12l-5-3c-4 3-10 2-13-3z"/><circle cx="9" cy="11" r=".9"/>',
  mountain: '<path d="M2 20l7-12 4.500 7 3-4.500L22 20z"/>',
  drop: '<path d="M12 3s6 6.500 6 11a6 6 0 0 1-12 0c0-4.500 6-11 6-11z"/>',
  recycle: '<path d="M21 12a9 9 0 0 1-15.500 6.200"/><path d="M3 12a9 9 0 0 1 15.500-6.200"/><path d="M18.500 2v4h-4"/><path d="M5.500 22v-4h4"/>',
  bug: '<ellipse cx="12" cy="14" rx="4" ry="6"/><path d="M12 8V5M8 6l2 2M16 6l-2 2M4 12h4M16 12h4M5 19l3-2M19 19l-3-2"/>',
  coconut: '<circle cx="12" cy="12" r="9"/><circle cx="9" cy="10" r="1"/><circle cx="14" cy="9" r="1"/><circle cx="12" cy="14" r="1"/>',
  hex: '<path d="M12 2l8.500 5v10L12 22l-8.500-5V7z"/><path d="M12 8l4 2.300v4.400L12 17l-4-2.300v-4.400z"/>',
  flower: '<circle cx="12" cy="12" r="2.500"/><path d="M12 9.500C10 7 10 4 12 2c2 2 2 5 0 7.500zM12 14.500c2 2.500 2 5.500 0 7.500-2-2-2-5 0-7.500zM9.500 12C7 10 4 10 2 12c2 2 5 2 7.500 0zM14.500 12c2.500-2 5.500-2 7.500 0-2 2-5 2-7.500 0z"/>',
  basket: '<path d="M3 9h18l-2 11H5z"/><path d="M8 9l4-6 4 6"/>',
  flame: '<path d="M12 22c4 0 7-3 7-7 0-4-3-6-4-10-2 1-4 4-4 7-1-1-2-2-2-4-2 2-4 4-4 7 0 4 3 7 7 7z"/>',
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
  heart: '<path d="M12 21s-8-5.500-8-11a4.500 4.500 0 0 1 8-2.800A4.500 4.500 0 0 1 20 10c0 5.500-8 11-8 11z"/>',
  award: '<circle cx="12" cy="9" r="6"/><path d="M8.500 14L7 22l5-3 5 3-1.500-8"/>',
  handshake: '<path d="M2 12l4-4 4 2 3-2 4 3 5-1"/><path d="M6 8l-4 4 6 6 3-2 4 3 5-5-3-3"/>',
  news: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/>',
  play: '<circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.500 9a2.500 2.500 0 1 1 3.500 2.300c-.7.4-1 1-1 1.700M12 17h.01"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  phone: '<path d="M5 4h4l2 5-2.500 1.500a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  chevron: '<path d="M6 9l6 6 6-6"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.500-4.500"/>',
  check: '<path d="M4 12l5 5L20 6"/>',
};
const icon = (n, cls = "") => `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ICONS.leaf}</svg>`;

/* ---------------------------------------------------------------- helpers */
const rootOf = (depth) => (depth === 0 ? "" : "../".repeat(depth));
const href = (root, target) => `${root}${target.endsWith("index") || target.includes("#") ? target : target}.html`.replace(".html.html", ".html");
const sectionOf = (key) => sections.find((s) => s.key === key);
const pagesIn = (key) => Object.values(pages).filter((p) => p.section === key);
const hash = (s) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);

const LOGO = `<svg class="logo-mark" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="23" fill="#1F4D2B"/><path d="M24 39V22" stroke="#F6F1E7" stroke-width="2.4" stroke-linecap="round"/><path d="M24 25c0-6-4.500-9.500-12-9.500 0 6.500 3.500 9.500 12 9.500z" fill="#A7C77A"/><path d="M24 29c0-5.500 4-9 11-9 0 6-4 9-11 9z" fill="#F6F1E7"/><circle cx="24" cy="10" r="3" fill="#E0A526"/></svg>`;

/* ---------------------------------------------------------------- images
   K() = Kairali's own photos, hotlinked from kairalimscs.com (replace with local copies before launch).
   L() = photos supplied by the team (compressed copies in src/img). These show NCUI events in UP / Uttarakhand,
         NOT Kairali's Kerala/TN operations — only used where captioned as NCUI/partner events. */
let CUR_ROOT = "";
const KU = "https://kairalimscs.com/wp-content/uploads/";
const K = (path, alt) => ({ src: KU + path, alt, credit: "Kairali" });
const L = (file, alt) => ({ local: file, alt, credit: "NCUI event" });
/* Wikimedia Commons (freely licensed, credit shown) — temporary field photography until Kairali supplies its own */
const C = (file, alt, fb) => ({ src: "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodeURIComponent(file) + "?width=1600", alt, fb, credit: "Wikimedia Commons", page: "https://commons.wikimedia.org/wiki/File:" + encodeURIComponent(file.replace(/ /g, "_")) });
const IMG = {
  "Commons — Kuttanad rice farmers": C("FARMERS ENGAGED IN RICE CULTIVATION, KUTTANAD.jpg", "Farmers working in a paddy field in Kuttanad, Kerala", "Carbon Credit Project"),
  "Commons — preparing land": C("Manual work preparing land for rice cultivation.jpg", "A farmer preparing a paddy field by hand", "Carbon Credit Project (2)"),
  "Commons — Kuttanad fishing": C("A bit of fishing for the dinner!.jpg", "Fishing in the backwaters of Kuttanad, Kerala", "Liquid Tree inauguration"),
  "Kera Tech — Virgin Plus": { src: KU + "2023/05/Virgin-Plus.jpg", alt: "Kairali Virgin Plus coconut oil", fb: KU + "2023/05/Virgin-Plus-300x300.jpg", credit: "Kairali" },
  "Kairali members at a community training session": K("2026/04/WhatsApp-Image-2026-04-11-at-5.14.57-PM-768x512.jpeg", "Members and staff gathered at the inauguration of Kairali's 50th branch"),
  "Portrait — Sri. Asokan K. V., Chairman": K("2023/09/Ph01.png", "Sri. Asokan K. V., Chairman of Kairali"),
  "Certificate of Registration (scan)": K("2023/04/cer-1-694x1024.png", "Certificate of Registration of Kairali Agriculture Multi State Co-operative Society Ltd., Regd. No. MSCS/CR/1346/2022"),
  "Liquid Tree inauguration event": K("2024/12/01-LT-768x576.png", "Liquid Tree inauguration"),
  "Award ceremony photographs": K("2024/11/004-Vayalar-768x576.jpeg", "Kairali receiving the Vayalar Karmasreshta Award 2024"),
  "50th branch inauguration": K("2026/04/WhatsApp-Image-2026-04-11-at-5.14.59-PM-768x512.jpeg", "Inauguration of Kairali's 50th branch"),
  "50th branch — lamp lighting": K("2026/04/WhatsApp-Image-2026-04-11-at-5.14.55-PM-768x512.jpeg", "Guests at Kairali's 50th branch inauguration"),
  "NCUI MoU signing": K("2026/04/20251118_205431-768x445.jpg", "MoU signing between Kairali and NCUI"),
  "Gold Standard, Geneva": K("2024/11/002-GS-768x576.jpg", "Kairali's meeting at the Gold Standard head office, Geneva"),
  "Gold Standard, Geneva (2)": K("2024/11/001-GS-768x576.jpg", "Kairali team at Gold Standard, Geneva"),
  "Vayalar Karmasreshta Award": K("2024/11/002-Vayalar-768x576.jpeg", "Vayalar Karmasreshta Award 2024"),
  "Liquid Tree inauguration": K("2024/12/02-LT-768x576.png", "Liquid Tree inauguration"),
  "Climate Agro inauguration": K("2026/04/WhatsApp-Image-2026-04-11-at-5.16.56-PM-768x576.jpeg", "Climate Agro inauguration"),
  "Jawaharlal Nehru Excellence Award 2026": K("2026/07/WhatsApp-Image-2026-07-02-at-7.43.23-PM-768x552.jpeg", "Jawaharlal Nehru Excellence Award 2026"),
  "Best Environmental Activist Award": K("2024/05/KAU1-768x576.png", "Best Environmental Activist Award"),
  "Meeting with IFFCO Chairman": K("2024/11/GUJ01-768x576.png", "Meeting with Sri. Dileep Sanghani, Chairman of IFFCO"),
  "Kairali TV — Snehadharam": K("2025/01/2-Kathir-768x576.png", "Kairali TV Snehadharam feature"),
  "Carbon Credit Project": K("2024/03/CCP1-768x432.png", "Kairali Carbon Credit Project"),
  "Carbon Credit Project (2)": K("2024/03/CCP2-768x432.png", "Kairali Carbon Credit Project"),
  "Carbon Credit Project (3)": K("2024/03/CCP3-768x432.png", "Kairali Carbon Credit Project"),
  /* team-supplied NCUI event photos */
  "NCUI — herbal processing training": L("herbal-sorting-3.jpg", "Women sorting fresh herbs at an NCUI-supported processing unit"),
  "NCUI — herbal sorting": L("herbal-sorting-1.jpg", "Women in hairnets sorting herbs at a processing table"),
  "NCUI — herbal tea training": L("herbal-tea-training.jpg", "Participants at a three-day herbal tea training, Uttarakhand"),
  "NCUI — women's cooperative session": L("ncui-women-session.jpg", "Women cooperative members in a group session"),
  "NCUI — group discussion": L("ncui-group-discussion.jpg", "Women members in small-group discussions"),
  "NCUI — gathering": L("ncui-hall-gathering.jpg", "A large gathering of women cooperative members"),
  "NCUI — cooperative fair": L("ncui-fair-stalls.jpg", "Stalls at an NCUI cooperative fair"),
  "NCUI — stall visitors": L("ncui-stall-visitors.jpg", "Visitors at an NCUI stall"),
  "NCUI — product stall": L("product-stall-1.jpg", "A cooperative product stall with packaged foods"),
  "NCUI — felicitation": L("ncui-stage-group.jpg", "Women members felicitated on stage"),
  "NCUI — Ubantu Happiness Centre": L("centre-inauguration.jpg", "Inauguration of the Ubantu Happiness Centre, Ghiwahi, Uttar Pradesh, 25 March 2026"),
  "NCUI — FPO group photo": L("fpo-group-photo.jpg", "Farmer producer organisation members and guests, Sonbhadra, Uttar Pradesh"),
  "NCUI — panel": L("ncui-panel.jpg", "Panel discussion with an NCUI representative"),
};
/* Remote Kairali images: if `node fetch-images.js` has saved a local copy, use it; otherwise hotlink. */
const REMOTE = new Set();
const KDIR = path.join(__dirname, "src/img/kairali");
const localName = (url) => decodeURIComponent((url.split("/uploads/")[1] || url.split("/").pop()).split("?")[0]).replace(/[^A-Za-z0-9._-]+/g, "_");
function resolveImg(url) {
  REMOTE.add(url);
  return fs.existsSync(path.join(KDIR, localName(url))) ? "kairali/" + localName(url) : null;
}
const srcOf = (im) => { if (!im) return ""; const loc = im.local || (im.src && resolveImg(im.src)); return loc ? `${CUR_ROOT}assets/img/${loc}` : im.src; };
function imgTag(im, cls = "", eager = false) {
  const f = im.fb ? (IMG[im.fb] || { src: im.fb }) : null;
  const fb = f ? srcOf(f) : "";
  return `<img class="${cls}" src="${srcOf(im)}" alt="${im.alt}"${eager ? ' fetchpriority="high"' : ' loading="lazy"'} decoding="async"${fb ? ` data-fb="${fb}"` : ""} onerror="if(this.dataset.fb){this.src=this.dataset.fb;this.removeAttribute('data-fb')}else{this.parentNode.classList.add('img-fail');this.remove()}">`;
}

/* photo frame — real image when one is registered, otherwise a clearly-labelled placeholder */
function ph(caption, ratio = "wide", extra = "") {
  const im = IMG[caption];
  if (im) return `<figure class="ph ph-${ratio} has-img ${extra}">${imgTag(im)}<div class="ph-art" aria-hidden="true">${icon("leaf", "ph-ic")}</div>${im.credit === "NCUI event" ? `<figcaption class="credit">NCUI event</figcaption>` : ""}</figure>`;
  const tone = hash(caption) % 4;
  return `<figure class="ph ph-${ratio} tone-${tone} ${extra}"><div class="ph-art">${icon(["leaf", "sun", "sprout", "tree"][tone], "ph-ic")}</div><figcaption><span>Photo placeholder</span>${caption}</figcaption></figure>`;
}

/* brochure PDFs that already exist on kairalimscs.com */
const PDFS = {
  "Carbon Credit Project|Brochure — English": KU + "2023/07/CCP-Brochure-English-Web.pdf",
  "Carbon Credit Project|Brochure — Malayalam": KU + "2023/07/CARBON-CREDIT-Brochure-Malayalam-Web.pdf",
  "Carbon Credit Project|Brochure — Tamil": KU + "2023/07/CARBON-CREDIT-Tamil.pdf",
  "Carbon Credit Project|Syllabus — English": KU + "2024/01/Carbon-Credit-Syllabus-English-1.pdf",
  "Carbon Credit Project|Syllabus — Malayalam": KU + "2024/01/Carbon-Credit-Syllabus-Malayalam-2.pdf",
  "Carbon Credit Project|Booklet — Malayalam": KU + "2024/11/CCP-BOOKLET.pdf",
  "Carbon Credit Project|Notice — Malayalam": KU + "2024/01/CCP-Mal.-Notice-02-01-24.pdf",
  "Green Pad|Brochure — English": KU + "2024/03/GREEN-PAD.pdf",
  "Green Pad|Brochure — Malayalam": KU + "2024/11/Green-Pad-Malayalam.pdf",
};

/* ---------------------------------------------------------------- block renderers */
function renderBlocks(blocks, ctx) {
  return blocks.map((b) => renderBlock(b, ctx)).join("\n");
}

function renderBlock(b, ctx) {
  const root = ctx.root;
  switch (b.t) {
    case "p": return `<p>${b.x}</p>`;
    case "h": return `<h3 class="h-sub">${b.x}</h3>`;
    case "ul": return `<ul class="tick">${b.items.map((i) => `<li>${icon("check")}<span>${i}</span></li>`).join("")}</ul>`;
    case "chips": return `<ul class="chips">${b.items.map((i) => `<li>${i}</li>`).join("")}</ul>`;
    case "pending": return `<aside class="pending"><span class="pending-tag">Pending from Kairali</span>${b.x}</aside>`;
    case "quote": return `<blockquote class="quote"><p>${b.x}</p>${b.by ? `<cite>${b.by}</cite>` : ""}</blockquote>`;
    case "photo": return ph(b.x, b.ratio || "wide");
    case "photoText":
      return `<div class="photo-text ${b.flip ? "flip" : ""}">${ph(b.photo, "arch")}<div class="pt-body">${renderBlocks(b.body, ctx)}</div></div>`;
    case "split2":
      return `<div class="split2"><div>${renderBlocks(b.left, ctx)}</div><div>${renderBlocks(b.right, ctx)}</div></div>`;
    case "callout": {
      const link = b.href ? `<a class="btn btn-ghost" href="${href(root, b.href)}">${b.cta || "Learn more"} ${icon("arrow")}</a>` : "";
      return `<div class="callout"><div><h4>${b.title}</h4><p>${b.x}</p></div>${link}</div>`;
    }
    case "kv":
      return `<dl class="kv">${b.items.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join("")}</dl>`;
    case "cards":
      return `<div class="cards cols-${b.cols || 3}">${b.items.map((c) => {
        const inner = `<span class="card-ic">${icon(c.icon || "leaf")}</span><h4>${c.title}</h4>${c.text ? `<p>${c.text}</p>` : ""}${c.href ? `<span class="card-more">Read more ${icon("arrow")}</span>` : ""}`;
        return c.href ? `<a class="card" href="${href(root, c.href)}">${inner}</a>` : `<div class="card">${inner}</div>`;
      }).join("")}</div>`;
    case "catalog": return renderCatalog(products.filter((p) => p.brand === b.brand), false);
    case "products":
      return `<div class="products">${b.items.map((p) => {
        const tone = hash(p.name) % 4;
        return `<article class="product tone-${tone}"><div class="product-art">${icon(ctx.page && ctx.page.icon ? ctx.page.icon : "jar", "product-ic")}<span class="tag">${p.tag}</span></div><div class="product-body"><h4>${p.name}</h4>${p.text ? `<p>${p.text}</p>` : ""}${p.price ? `<div class="price">MRP ${p.price}</div>` : ""}</div></article>`;
      }).join("")}</div>`;
    case "table":
      return `<div class="table-wrap"><table><thead><tr>${b.head.map((h) => `<th>${h}</th>`).join("")}</tr></thead><tbody>${b.rows.map((r) => `<tr>${r.map((c, i) => (i === 0 ? `<th scope="row">${c}</th>` : `<td>${c}</td>`)).join("")}</tr>`).join("")}</tbody></table></div>`;
    case "timeline":
      return `<ol class="timeline">${b.items.map((i) => `<li><span class="tl-year">${i.y}</span><p>${i.x}</p></li>`).join("")}</ol>`;
    case "faq":
      return `<div class="faq">${b.items.map((f) => `<details><summary>${f.q}${icon("chevron")}</summary><p>${f.a}</p></details>`).join("")}</div>`;
    case "steps":
      return `<ol class="steps">${b.items.map((s, i) => `<li><span class="step-n">${i + 1}</span><div><h4>${s.h}</h4><p>${s.x}</p></div></li>`).join("")}</ol>`;
    case "sdg":
      return `<div class="sdg">${b.items.map((s) => `<div class="sdg-tile" style="--c:${s.c}"><span class="sdg-n">${s.n}</span><strong>${s.l}</strong><small>${s.w}</small></div>`).join("")}</div>`;
    case "news":
      { const tags = [...new Set(b.items.map((n) => n.tag))];
      return `<div class="news-filter chips-filter" role="toolbar" aria-label="Filter news by type"><button type="button" class="chip-btn on" data-tag="" aria-pressed="true">All <small>${b.items.length}</small></button>${tags.map((t) => `<button type="button" class="chip-btn" data-tag="${t}" aria-pressed="false">${t} <small>${b.items.filter((n) => n.tag === t).length}</small></button>`).join("")}</div>
      <div class="news-list">${b.items.map((n) => `<article class="news-item" data-tag="${n.tag}"><span class="news-date">${n.d}</span><div><span class="tag">${n.tag}</span><h4>${n.title}</h4>${n.x ? `<p>${n.x}</p>` : ""}</div></article>`).join("")}</div>`; }
    case "gallery":
      return `<div class="gallery">${b.items.map((c, i) => { const im = IMG[c]; const fig = ph(c, i % 5 === 0 ? "wide" : "square", i % 5 === 0 ? "g-span" : ""); return im ? `<button type="button" class="g-item ${i % 5 === 0 ? "g-span" : ""}" data-full="${im.local ? CUR_ROOT + "assets/img/" + im.local : im.src}" data-cap="${im.alt}">${fig}</button>` : fig; }).join("")}</div>`;
    case "downloads":
      return `<div class="downloads">${b.groups.map((g) => `<section class="dl-group"><h4>${g.title}</h4><ul>${g.files.map((f) => { const u = PDFS[g.title + "|" + f]; return `<li><a href="${u || "#"}" class="dl${u ? "" : " dl-missing"}"${u ? ' target="_blank" rel="noopener"' : ' title="File to be attached"'}>${icon("download")}<span>${f}</span><small>${u ? "PDF · kairalimscs.com" : "PDF · to be attached"}</small></a></li>`; }).join("")}</ul></section>`).join("")}</div>`;
    case "docs":
      return `<div class="docs-box"><h4>${icon("download")} ${b.title || "Brochures for this page"}</h4><ul>${b.files.map(([label, key]) => { const u = PDFS[key]; return u ? `<li><a class="dl" href="${u}" target="_blank" rel="noopener">${icon("download")}<span>${label}</span><small>PDF</small></a></li>` : ""; }).join("")}</ul><a class="link-arrow" href="${CUR_ROOT}media/resources-downloads.html">All downloads ${icon("arrow")}</a></div>`;
    case "schemes":
      return `<nav class="scheme-jump" aria-label="Jump to a scheme">${b.items.map((c) => `<a class="chip-btn" href="#${c.id}">${c.title}</a>`).join("")}</nav>${b.items.map((c) => `<section class="scheme" id="${c.id}"><span class="card-ic">${icon(c.icon)}</span><div><h3>${c.title}</h3><p class="scheme-for"><em>${c.for}</em></p><p>${c.text}</p><ul class="tick">${c.points.map((x) => `<li>${icon("check")}<span>${x}</span></li>`).join("")}</ul><a class="btn btn-clay" href="${CUR_ROOT}contact/contact-enquiry.html">Ask about ${c.title} ${icon("arrow")}</a></div></section>`).join("")}`;
    case "branches": return renderBranches();
    case "contactform":
      return `<div class="split2 contact-split"><form class="form" id="enquiry-form" novalidate><label>Name<input required name="name" autocomplete="name"></label><label>Email<input required type="email" name="email" autocomplete="email"></label><label>Subject<input required name="subject"></label><label>Message<textarea required name="message" rows="5"></textarea></label><button class="btn btn-clay" type="submit">Send message ${icon("arrow")}</button><p class="form-note" role="status" hidden>Thank you — this is a sample form, so nothing was sent.</p></form><div>${renderBlocks([{ t: "kv", items: [["Head office", "Kovilakam Tower, Warriam Lane, Thekkemadom Road, Thrissur – 680001"], ["Phone", "0487 – 242 6366 · +91 8078900222"], ["Email", "info@kairalimscs.com"]] }, ], ctx)}<div class="map-wrap"><iframe title="Map — Kairali head office, Thrissur" src="https://www.google.com/maps?q=Kovilakam+Tower,+Thekkemadom+Road,+Thrissur&output=embed" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div></div></div>`;
    default: return "";
  }
}

function priceHtml(p) {
  return p.price ? `<span class="price"><small>MRP</small> ${p.price}</span>` : `<span class="price na">Price on request</span>`;
}
function renderCatalog(list, showBrand) {
  return `<div class="products">${list.map((p) => `<article class="product" data-id="${p.id}" data-brand="${p.brand}" data-text="${(p.name + " " + p.cat + " " + brands[p.brand].label).toLowerCase()}">
  <div class="product-img">${imgTag({ src: p.img, alt: p.name })}<span class="p-fallback" aria-hidden="true">${icon("jar")}</span><span class="tag">${p.cat}</span></div>
  <div class="product-body">${showBrand ? `<a class="p-brand" href="${CUR_ROOT}products/${brands[p.brand].page}.html">${brands[p.brand].label}</a>` : ""}<h4>${p.name}</h4><p>${p.desc}</p>${p.long ? `<button type="button" class="p-more" data-id="${p.id}">Full details ${icon("arrow")}</button>` : `<button type="button" class="p-more" data-id="${p.id}">Details ${icon("arrow")}</button>`}
  ${p.draft ? `<aside class="pending mini"><span class="pending-tag">Draft copy</span>Written from the product name — Kairali to confirm.</aside>` : ""}
  <div class="p-meta">${priceHtml(p)}${p.size ? `<span class="size">${p.size}</span>` : ""}</div>
  <div class="p-actions"><div class="qty" role="group" aria-label="Quantity for ${p.name}"><button type="button" class="q-minus" aria-label="Decrease quantity">−</button><input type="number" min="1" max="99" value="1" inputmode="numeric" aria-label="Quantity"><button type="button" class="q-plus" aria-label="Increase quantity">+</button></div><button type="button" class="btn btn-clay add-basket" data-id="${p.id}">${icon("basket")} Add to basket</button></div>
  </div></article>`).join("")}</div>`;
}

function shopIndex(s) {
  const root = rootOf(1); CUR_ROOT = root;
  const chips = [["", "All products", products.length], ...Object.entries(brands).map(([k, v]) => [k, v.label, products.filter((p) => p.brand === k).length])];
  const body = `
<section class="page-banner"><div class="container">
  <nav class="crumbs" aria-label="Breadcrumb"><a href="${root}index.html">Home</a><span>/</span><span aria-current="page">${s.label}</span></nav>
  <h1>From our farms, <em>to your home</em></h1><p class="banner-lead">${s.lead}</p></div>${bannerArt()}</section>
<div class="container shop">
  <div class="shop-note">${icon("basket")}<p><strong>How ordering works.</strong> <em>Add what you need to your basket and send it to us.</em> Our team confirms availability, the final price and pickup or delivery with you — nothing is charged online.</p></div>
  <div class="shop-tools"><div class="chips-filter" role="toolbar" aria-label="Filter by range">${chips.map(([k, l, n], i) => `<button type="button" class="chip-btn${i === 0 ? " on" : ""}" data-brand="${k}" aria-pressed="${i === 0}">${l} <small>${n}</small></button>`).join("")}</div>
  <label class="search">${icon("search")}<input id="shop-q" type="search" placeholder="Search honey, coconut oil, cleaner…" aria-label="Search products"></label></div>
  <p class="shop-count" aria-live="polite"><strong id="shop-n">${products.length}</strong> products</p>
  ${renderCatalog(products, true)}
  <p class="shop-empty" hidden>No products match that search. Try another word or clear the filter.</p>
  <div class="callout"><div><h4>Looking for groceries?</h4><p>Flours, pulses, spices, oils and household essentials are sold at Kairali branches.</p></div><a class="btn btn-ghost" href="${root}products/fmcg-products.html">See the FMCG range ${icon("arrow")}</a></div>
  <aside class="pending"><span class="pending-tag">Pending from Kairali</span>Basket orders are sent to Kairali by WhatsApp or email — confirm which number/inbox should receive them and who follows up. Prices are MRP from the internal list and need finance sign-off; items without a single MRP show "Price on request".</aside>
</div>
${ctaStrip(root)}`;
  return shell({ title: "Products", root, active: s.key, body, desc: s.lead });
}

function renderBranches() {
  const all = branches.all;
  const districts = [...new Set(all.map((b) => `${b.state}|${b.district}`))].sort();
  const cards = all.map((b) => `<article class="branch" data-state="${b.state}" data-district="${b.district}" data-text="${(b.name + " " + b.district + " " + b.address).toLowerCase()}"><header><h4>${b.name}</h4><span class="tag">${b.district}</span></header><p>${b.address}</p><ul>${b.phone ? `<li>${icon("phone")} ${b.phone}</li>` : ""}<li>${icon("mail")} <a href="mailto:${b.email}">${b.email}</a></li></ul></article>`).join("");
  return `<div class="branch-tools"><label class="search">${icon("search")}<input id="branch-q" type="search" placeholder="Search town, district or address"></label><select id="branch-state" aria-label="State"><option value="">All states</option><option>Kerala</option><option>Tamil Nadu</option></select><select id="branch-district" aria-label="District"><option value="">All districts</option>${districts.map((d) => { const [s, n] = d.split("|"); return `<option data-state="${s}" value="${n}">${n}</option>`; }).join("")}</select></div><p class="branch-count" aria-live="polite"><strong id="branch-n">${all.length}</strong> branches · ${branches.kerala.length} in Kerala · ${branches.tamilnadu.length} in Tamil Nadu</p><div class="branch-grid" id="branch-grid">${cards}</div><aside class="pending"><span class="pending-tag">Pending from Kairali</span>Directory captured from the current live site — please run one final verification against internal records before launch. Phone numbers are missing for Koduvayur, Kuttikol and Chidambaram.</aside>`;
}

/* official Kairali logo from kairalimscs.com; falls back to the drawn mark + wordmark if it can't load */
function officialLogo(cls) {
  const im = { src: KU + "2023/04/Kairali-Logo-F-1.png", alt: "Kairali Agriculture MSCS Ltd." };
  return `<img class="${cls} off-logo" src="${srcOf(im)}" alt="${im.alt}" width="180" height="62" decoding="async" onerror="this.parentNode.classList.add('logo-fail');this.remove()">`;
}

/* ---------------------------------------------------------------- shell */
function header(root, activeKey) {
  const menu = sections.map((s) => {
    const kids = pagesIn(s.key);
    const mega = `<div class="mega" role="group" aria-label="${s.label}"><div class="mega-intro"><span class="mega-ic">${icon(s.icon)}</span><h3>${s.label}</h3><p>${s.lead}</p><a class="mega-all" href="${root}${s.key}/index.html">Overview ${icon("arrow")}</a></div><ul class="mega-list">${kids.map((k) => `<li><a href="${root}${k.section}/${k.slug}.html"><span class="mega-li-ic">${icon(k.icon)}</span><span><strong>${k.label}</strong><small>${k.one}</small></span></a></li>`).join("")}</ul></div>`;
    return `<li class="has-mega ${activeKey === s.key ? "is-active" : ""}"><a class="nav-top" href="${root}${s.key}/index.html" aria-haspopup="true" aria-expanded="false">${s.label}${icon("chevron", "caret")}</a>${mega}</li>`;
  }).join("");
  return `<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
  <div class="topbar"><div class="container"><span>${icon("phone")} 0487 – 242 6366 · +91 8078900222</span><span class="tb-mail">${icon("mail")} info@kairalimscs.com</span><span class="tb-soc"><a href="https://www.youtube.com/@kairaliagriculture" target="_blank" rel="noopener">YouTube</a><a href="https://www.instagram.com/kairaliagriculture/" target="_blank" rel="noopener">Instagram</a><a href="https://www.facebook.com/KairaliAgriculture" target="_blank" rel="noopener">Facebook</a><a href="https://in.linkedin.com/company/kairaliagriculture" target="_blank" rel="noopener">LinkedIn</a></span></div></div>
  <div class="mainbar container">
    <a class="brand" href="${root}index.html" aria-label="Kairali Agriculture MSCS Ltd. — home">${officialLogo("brand-logo")}<span class="brand-fb">${LOGO}<span><strong>${SITE.name}</strong><small>${SITE.short}</small></span></span></a>
    <button class="menu-toggle" aria-label="Open menu" aria-expanded="false">${icon("menu", "i-open")}${icon("close", "i-close")}</button>
    <nav class="primary" aria-label="Primary"><ul>${menu}<li class="nav-cta"><a class="btn btn-clay" href="${root}membership/become-a-member.html">Become a Member</a></li></ul></nav>
    <button type="button" class="basket-btn" aria-controls="basket" aria-expanded="false">${icon("basket")}<span class="sr">Basket,</span><span class="basket-count" aria-live="polite">0</span><span class="sr">items</span></button>
    <a class="btn btn-clay head-cta" href="${root}membership/become-a-member.html">Become a Member</a>
  </div>
</header>`;
}

function footer(root) {
  return `<footer class="site-footer"><div class="container foot-grid">
  <div class="foot-brand"><span class="foot-logo">${officialLogo("")}<span class="brand-fb">${LOGO}</span></span><h3>${SITE.name}</h3><p>${SITE.full} — registered under the Ministry of Cooperation, Government of India. Regd. No. MSCS/CR/1346/2022.</p></div>
  ${["about", "green-initiatives", "products", "membership"].map((k) => { const s = sectionOf(k); return `<div><h4>${s.label}</h4><ul>${pagesIn(k).map((p) => `<li><a href="${root}${p.section}/${p.slug}.html">${p.label}</a></li>`).join("")}</ul></div>`; }).join("")}
  <div><h4>Head office</h4><p>Kovilakam Tower, Warriam Lane,<br>Thekkemadom Road, Thrissur – 680001<br>Kerala, India</p><p>${icon("phone")} 0487 – 242 6366<br>${icon("phone")} +91 8078900222<br>${icon("mail")} info@kairalimscs.com</p></div>
  </div><div class="foot-base container"><span>© <span data-year>${new Date().getFullYear()}</span> ${SITE.full} — sample draft, not for publication.</span><span><a href="${root}contact/branch-network.html">${branches.all.length} branches</a> · <a href="${root}media/resources-downloads.html">Downloads</a> · <a href="${root}contact/contact-enquiry.html">Contact</a></span></div></footer>
<div class="basket-scrim" hidden></div>
<aside class="basket" id="basket" role="dialog" aria-modal="true" aria-labelledby="basket-h" hidden>
  <header><h2 id="basket-h">Your <em>basket</em></h2><button type="button" class="basket-close" aria-label="Close basket">${icon("close")}</button></header>
  <div class="basket-body"><ul class="basket-list"></ul>
    <div class="basket-empty"><p><strong>Your basket is empty.</strong> <em>Browse honey, coconut products and home care</em> and add what you need.</p><a class="btn btn-green" href="${root}products/index.html">Browse products</a></div>
    <div class="basket-sum"></div>
    <form class="basket-form" novalidate>
      <h3>Send your order</h3>
      <label>Name<input name="name" required autocomplete="name"></label>
      <label>Phone<input name="phone" required type="tel" autocomplete="tel" pattern="[0-9+ \-]{10,15}"></label>
      <label>Nearest branch or delivery address<input name="where" required placeholder="e.g. Chalakudy branch, or your address"></label>
      <p class="form-err" role="alert" hidden>Please fill in your name, a valid phone number and a branch or address.</p>
      <div class="basket-send"><button type="submit" class="btn btn-clay" data-via="whatsapp">Send on WhatsApp</button><button type="submit" class="btn btn-outline" data-via="email">Send by email</button></div>
      <p class="fine"><em>Nothing is charged online.</em> Kairali confirms availability, the final price and pickup or delivery with you.</p>
    </form>
  </div>
</aside>
<div class="toast" role="status" aria-live="polite" hidden></div>
<dialog class="pmodal" aria-labelledby="pm-title"><button type="button" class="pm-close" aria-label="Close details">${icon("close")}</button>
  <div class="pm-grid"><div class="pm-img"><img alt=""><span class="p-fallback" aria-hidden="true">${icon("jar")}</span></div>
  <div class="pm-body"><p class="p-brand pm-brand"></p><h2 id="pm-title"></h2><p class="pm-long"></p>
    <div class="pm-lists"><div class="pm-feat"><h3>Highlights</h3><ul class="tick"></ul></div><div class="pm-uses"><h3>How to use it</h3><ul class="chips"></ul></div></div>
    <aside class="pending mini pm-draft"><span class="pending-tag">Draft copy</span>Kairali's site has no description for this product yet — written from the product name. Kairali to confirm.</aside>
    <div class="p-meta pm-meta"></div>
    <div class="p-actions"><div class="qty" role="group" aria-label="Quantity"><button type="button" class="q-minus" aria-label="Decrease quantity">−</button><input type="number" min="1" max="99" value="1" aria-label="Quantity"><button type="button" class="q-plus" aria-label="Increase quantity">+</button></div><button type="button" class="btn btn-clay add-basket pm-add">${icon("basket")} Add to basket</button></div>
    <a class="pm-src" target="_blank" rel="noopener">View on kairalimscs.com</a>
  </div></div></dialog>
<dialog class="lightbox" aria-label="Photo viewer"><button type="button" class="lb-close" aria-label="Close photo">${icon("close")}</button><img alt=""><p class="lb-cap"></p></dialog>
<button class="review-toggle" type="button" aria-pressed="false" title="Show the items Kairali still needs to confirm">${icon("help")}<span>Review mode</span></button>`;
}

function shell({ title, root, active, body, desc, home }) {
  return `<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}${home ? "" : " · Kairali"}</title>
<meta name="description" content="${desc || SITE.full}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400..800;1,9..144,400..700&family=Nunito:ital,wght@0,400..800;1,400..700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="${root}assets/style.css">
<link rel="icon" href="${srcOf({ src: KU + "2023/04/cropped-K.Logo_-270x270.png" })}">
</head><body class="${home ? "is-home" : ""}">
${header(root, active)}
<main id="main">${body}</main>
${footer(root)}
<script src="${root}assets/catalog.js"></script>
<script src="${root}assets/main.js"></script>
</body></html>`;
}

/* ---------------------------------------------------------------- page types */
function subPage(p) {
  const root = rootOf(1); CUR_ROOT = root;
  const sec = sectionOf(p.section);
  const sibs = pagesIn(p.section);
  const body = `
<section class="page-banner"><div class="container">
  <nav class="crumbs" aria-label="Breadcrumb"><a href="${root}index.html">Home</a><span>/</span><a href="${root}${sec.key}/index.html">${sec.label}</a><span>/</span><span aria-current="page">${p.label}</span></nav>
  <h1>${p.label}</h1><p class="banner-lead">${p.one}</p>
</div>${bannerArt()}</section>
<div class="container layout">
  <aside class="subnav" aria-label="${sec.label}"><h2>${sec.label}</h2><ul>${sibs.map((s) => `<li><a class="${s.slug === p.slug ? "on" : ""}" href="${root}${s.section}/${s.slug}.html">${icon(s.icon)}<span>${s.label}</span></a></li>`).join("")}</ul></aside>
  <article class="content">${renderBlocks(p.blocks, { root, page: p })}</article>
</div>
${ctaStrip(root)}`;
  return shell({ title: p.label, root, active: p.section, body, desc: p.one });
}

function sectionIndex(s) {
  if (s.key === "products") return shopIndex(s);
  const root = rootOf(1); CUR_ROOT = root;
  const kids = pagesIn(s.key);
  const body = `
<section class="page-banner"><div class="container">
  <nav class="crumbs" aria-label="Breadcrumb"><a href="${root}index.html">Home</a><span>/</span><span aria-current="page">${s.label}</span></nav>
  <h1>${s.label}</h1><p class="banner-lead">${s.lead}</p></div>${bannerArt()}</section>
<div class="container section-index"><div class="cards cols-3">${kids.map((k) => `<a class="card" href="${root}${k.section}/${k.slug}.html"><span class="card-ic">${icon(k.icon)}</span><h4>${k.label}</h4><p>${k.one}</p><span class="card-more">Explore ${icon("arrow")}</span></a>`).join("")}</div></div>
${ctaStrip(root)}`;
  return shell({ title: s.label, root, active: s.key, body, desc: s.lead });
}

function bannerArt() {
  return `<svg class="banner-art" viewBox="0 0 600 200" preserveAspectRatio="xMaxYMax slice" aria-hidden="true"><g fill="none" stroke="#A7C77A" stroke-width="1.4" opacity=".55"><path d="M420 200c0-60 30-100 80-120"/><path d="M500 200c0-40 20-70 60-90"/><path d="M340 200c10-40 40-70 90-80"/></g><g fill="#A7C77A" opacity=".5"><path d="M500 80c-20 0-32-14-32-30 24 0 32 14 32 30z"/><path d="M560 110c-18 0-28-12-28-26 20 0 28 12 28 26z"/><path d="M430 120c-20-2-30-14-30-30 22 2 32 14 30 30z"/></g></svg>`;
}

function ctaStrip(root) {
  return `<section class="cta-strip"><div class="container"><div><h2>Grow with <em>the cooperative</em></h2><p>Become a member, find a branch near you, or talk to our team about the Carbon Credit Project.</p></div><div class="cta-btns"><a class="btn btn-clay" href="${root}membership/become-a-member.html">Become a Member</a><a class="btn btn-light" href="${root}contact/branch-network.html">Find a branch</a></div></div></section>`;
}

/* ---------------------------------------------------------------- home */
function heroArt() {
  return `<svg viewBox="0 0 480 560" class="hero-svg" role="img" aria-label="Illustration of terraced fields under a rising sun">
  <defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F9E9B8"/><stop offset=".6" stop-color="#F6F1E7"/></linearGradient>
  <clipPath id="arch"><path d="M0 560V240C0 107 107 0 240 0s240 107 240 240v320z"/></clipPath></defs>
  <g clip-path="url(#arch)"><rect width="480" height="560" fill="url(#sky)"/>
  <circle cx="330" cy="170" r="62" fill="#E0A526" opacity=".9"/><circle cx="330" cy="170" r="86" fill="#E0A526" opacity=".18"/>
  <path d="M0 330c70-50 140-60 230-20s170 10 250-30v280H0z" fill="#A7C77A"/>
  <path d="M0 390c90-40 170-30 250 5s150 10 230-25v190H0z" fill="#6E9B4A"/>
  <path d="M0 450c100-30 190-20 270 10s140 0 210-20v120H0z" fill="#2F6B3A"/>
  <g stroke="#F6F1E7" stroke-width="1.6" opacity=".35" fill="none"><path d="M0 405c90-40 170-30 250 5s150 10 230-25"/><path d="M0 425c90-40 170-30 250 5s150 10 230-25"/><path d="M0 470c100-30 190-20 270 10s140 0 210-20"/><path d="M0 492c100-30 190-20 270 10s140 0 210-20"/></g>
  <g transform="translate(120 330)"><path d="M0 60V0" stroke="#1F4D2B" stroke-width="4" stroke-linecap="round"/><path d="M0 12C0-14-22-26-52-26c0 26 20 38 52 38z" fill="#F6F1E7"/><path d="M0 26c0-22 18-34 48-34 0 24-18 34-48 34z" fill="#DDEBC6"/></g>
  </g></svg>`;
}

function homePage() {
  const root = ""; CUR_ROOT = "";
  const news = pages["media/news-events"].blocks[0].items.slice(0, 3);
  const arrowBtns = (label) => `<button type="button" class="rail-btn prev" aria-label="Scroll ${label} left">${icon("arrow")}</button><button type="button" class="rail-btn next" aria-label="Scroll ${label} right">${icon("arrow")}</button>`;
  const credit = (im) => im.credit === "Wikimedia Commons" ? `<a class="photo-credit" href="${im.page}" target="_blank" rel="noopener">Photo: Wikimedia Commons</a>` : "";

  /* ---- 1. hero slider ---- */
  const slides = [
    { img: "Commons — Kuttanad rice farmers", kick: "Farmers · Cooperation · Livelihoods", h: `Growing together <em>for a sustainable tomorrow</em>`, p: "Kairali brings farmers together through cooperative action, sustainable agriculture and member services — so no one faces the market, or the climate, alone.", a: ["Become a Member", "membership/become-a-member"], b: ["Explore our work", "our-work/index"] },
    { img: "Carbon Credit Project", kick: "Carbon credits · Climate-smart farming", h: `From our fields <em>to a greener tomorrow</em>`, p: "Through the Carbon Credit Project, member-farmers adopt climate-smart practices and earn from the credits generated on their own land.", a: ["Join the Carbon Credit Project", "green-initiatives/carbon-credit-project"], b: ["See all green initiatives", "green-initiatives/index"] },
    { img: "Kera Tech — Virgin Plus", kick: "Coconut · Honey · Home care", h: `Creating opportunities <em>across agriculture</em>`, p: "Value-added products from Kairali's farms and cooperative network — from virgin coconut oil to Wayanad forest honey.", a: ["Shop our products", "products/index"], b: ["Find a branch", "contact/branch-network"] },
  ];
  const hero = `<section class="hero-slider" aria-roledescription="carousel" aria-label="Highlights from Kairali" data-autoplay="7000">
  <div class="hs-track">${slides.map((s, i) => { const im = IMG[s.img]; return `<article class="hs-slide${i === 0 ? " is-on" : ""}" role="group" aria-roledescription="slide" aria-label="${i + 1} of ${slides.length}"${i ? ' aria-hidden="true"' : ""}>
    <div class="hs-media ${s.img.startsWith("Kera") ? "is-product" : ""}">${imgTag(im, "", i === 0)}</div>
    <div class="container hs-copy"><p class="hs-kick">${s.kick}</p><${i === 0 ? "h1" : "h2"} class="hs-h">${s.h}</${i === 0 ? "h1" : "h2"}><p class="hs-p">${s.p}</p>
    <div class="hero-btns"><a class="btn btn-clay btn-lg" href="${s.a[1]}.html"${i ? ' tabindex="-1"' : ""}>${s.a[0]} ${icon("arrow")}</a><a class="btn btn-outline btn-lg" href="${s.b[1]}.html"${i ? ' tabindex="-1"' : ""}>${s.b[0]}</a></div></div>${credit(im)}</article>`; }).join("")}</div>
  <div class="hs-leaf" aria-hidden="true">${icon("sprout")}<span><em>From our farmers</em> to a greener tomorrow</span></div>
  <button type="button" class="hs-arrow prev" aria-label="Previous slide">${icon("arrow")}</button><button type="button" class="hs-arrow next" aria-label="Next slide">${icon("arrow")}</button>
  <div class="container hs-bar"><span class="hs-count" aria-live="polite"><strong>01</strong> / 0${slides.length}</span><div class="hs-dots">${slides.map((_, i) => `<button type="button" class="hs-dot${i === 0 ? " is-on" : ""}" aria-label="Go to slide ${i + 1}"><i></i></button>`).join("")}</div><button type="button" class="hs-pause" aria-label="Pause slideshow" aria-pressed="false"><span class="p-pause">❚❚</span><span class="p-play">▶</span></button></div>
</section>`;

  /* ---- 2. key areas strip ---- */
  const strip = `<section class="key-strip"><div class="container ks-row">${[
    ["sprout", "Sustainable Agriculture", "Climate-smart practices and eco-farming", "our-work/agriculture-rural-livelihoods"],
    ["users", "Farmer Empowerment", "Training, capacity building and livelihoods", "our-work/training-capacity-building"],
    ["sun", "Green Initiatives", "Carbon credits, Liquid Tree and BSFL", "green-initiatives/index"],
    ["basket", "Value-added Products", "From farm to market", "products/index"],
    ["handshake", "Cooperative Services", "Contribution schemes and member support", "our-work/member-cooperative-services"],
  ].map(([i, t, x, h]) => `<a class="ks-item" href="${h}.html"><span class="ks-ic">${icon(i)}</span><span><strong>${t}</strong><small>${x}</small></span></a>`).join("")}</div></section>`;

  /* ---- 3. about collage + impact ---- */
  const about = `<section class="section about-impact"><div class="container ai-grid">
  <div class="ai-text"><p class="kicker">About Kairali</p><h2>A cooperative for people, prosperity <em>and a healthier planet.</em></h2>
    <p><strong>Kairali Agriculture Multi State Co-operative Society Ltd.</strong> is registered under the Ministry of Cooperation, Government of India. From its head office in Thrissur, it serves farmer-members across Kerala and Tamil Nadu — with sustainable agriculture, cooperative services, value-added products and green initiatives.</p>
    <a class="btn btn-outline" href="about/about-kairali.html">Know more about us ${icon("arrow")}</a></div>
  <div class="collage" aria-hidden="false">
    <figure class="cl cl-a">${imgTag(IMG["50th branch inauguration"])}</figure>
    <figure class="cl cl-b">${imgTag(IMG["Commons — preparing land"])}</figure>
    <figure class="cl cl-c">${imgTag(IMG["Liquid Tree inauguration"])}</figure>
    <span class="cl-leaf" aria-hidden="true"></span>
  </div>
  <aside class="impact-card"><p class="kicker">Our reach</p><h3>Stronger farmers. <em>Greener communities.</em></h3>
    <div class="ic-grid">${[["users", 45000, "+", "Shareholders"], ["pin", branches.all.length, "", "Branches"], ["handshake", 500, "+", "Employees"], ["map", 2, "", "States — Kerala &amp; Tamil Nadu"]].map(([i, n, suf, l]) => `<div class="ic-tile"><span class="ks-ic">${icon(i)}</span><span><strong data-count="${n}" data-suffix="${suf}">${n.toLocaleString("en-IN")}${suf}</strong><small>${l}</small></span></div>`).join("")}</div>
    <a class="link-arrow" href="impact/our-impact.html">See our impact ${icon("arrow")}</a></aside>
</div></section>`;

  /* ---- 4. our work — scrollable image cards ---- */
  const work = [
    ["Commons — Kuttanad rice farmers", "Agriculture & Rural Livelihoods", "Livelihoods that make farming viable and dignified.", "our-work/agriculture-rural-livelihoods"],
    ["Commons — Kuttanad fishing", "Allied Farming", "Dairy, poultry and fisheries to diversify income.", "our-work/allied-farming"],
    ["Carbon Credit Project (2)", "Carbon Credit Project", "Earn from climate-smart, sustainable farming.", "green-initiatives/carbon-credit-project"],
    ["Liquid Tree inauguration", "Liquid Tree", "Kairali's newest environmental technology pilot.", "green-initiatives/liquid-tree"],
    ["Kera Tech — Virgin Plus", "Value-added Products", "Coconut, honey and home-care from our network.", "products/index"],
    ["50th branch inauguration", "Cooperative Services", "Contribution schemes and member support at 55 branches.", "our-work/member-cooperative-services"],
    ["Climate Agro inauguration", "Training & Capacity Building", "Skills and awareness for members and stakeholders.", "our-work/training-capacity-building"],
  ];
  const workRail = `<section class="section work-focus"><div class="container wf-grid">
  <div class="wf-intro"><p class="kicker">Our work in focus</p><h2>From our fields <em>to a greener tomorrow</em></h2><p>Explore the areas where Kairali works with farmers, communities and the environment.</p>
    <div class="rail-ctrl" data-for="work-rail">${arrowBtns("work areas")}</div><a class="link-arrow" href="our-work/index.html">Explore all initiatives ${icon("arrow")}</a></div>
  <div class="rail" id="work-rail" tabindex="0" aria-label="Work areas — scroll sideways"><ul class="rail-track">${work.map(([im, t, x, h]) => `<li><a class="wcard" href="${h}.html">${imgTag(IMG[im])}<span class="wc-body"><strong>${t}</strong><small>${x}</small></span><span class="wc-go">${icon("arrow")}</span></a></li>`).join("")}</ul></div>
</div></section>`;

  /* ---- 5. green band (kept) ---- */
  const green = `<section class="section green-band"><div class="container"><div class="sec-head light"><p class="kicker">Green initiatives</p><h2>Farming that <em>heals the land</em></h2><p>Environmental and sustainability projects, built around and for our farmer community.</p></div>
  <div class="green-grid">
    <a class="g-feature g-photo" href="green-initiatives/carbon-credit-project.html">${imgTag(IMG["Carbon Credit Project (3)"])}<span class="g-over"><h3>Carbon Credit Project</h3><p>Cutting emissions, cultivating greener lands and generating carbon credits that farmers earn from.</p><span class="card-more">Explore the project ${icon("arrow")}</span></span></a>
    <div class="g-list">${[["tree", "Integrated Eco Farm", "green-initiatives/integrated-eco-farm"], ["mountain", "Eco / Farm Tourism", "green-initiatives/eco-farm-tourism"], ["drop", "Liquid Tree", "green-initiatives/liquid-tree"], ["recycle", "BSFL / Waste Management", "green-initiatives/bsfl-waste-management"]].map(([i, t, h]) => `<a href="${h}.html">${icon(i)}<span>${t}</span>${icon("arrow")}</a>`).join("")}</div>
  </div></div></section>`;

  /* ---- 6. product rail with basket ---- */
  const featured = ["virgin-plus-oil", "wayanadan-honey", "coconut-chips", "black-forest-honey-250", "coconut-sugar", "chammanthi-podi", "hair-cream", "herbal-soap", "milk-powder", "green-pad", "laundry-detergent", "chukku-kappi"].map((id) => products.find((p) => p.id === id)).filter(Boolean);
  const prodRail = `<section class="section paper"><div class="container"><div class="sec-head row"><div><p class="kicker">From our farms</p><h2>Fresh from the cooperative, <em>straight to your basket</em></h2></div><div class="rail-ctrl" data-for="prod-rail">${arrowBtns("products")}</div></div>
  <div class="rail" id="prod-rail" tabindex="0" aria-label="Featured products — scroll sideways">${renderCatalog(featured, true).replace('class="products"', 'class="products rail-track"')}</div>
  <p class="center rail-cta"><a class="btn btn-clay" href="products/index.html">${icon("basket")} Shop all ${products.length} products</a></p></div></section>`;

  /* ---- 7. stories from the ground ---- */
  const stories = `<section class="stories-band"><div class="sb-grid">
  <a class="sb-video" href="https://www.youtube.com/@kairaliagriculture" target="_blank" rel="noopener">${imgTag(IMG["Kairali TV — Snehadharam"])}<span class="sb-play" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5l12 7-12 7z" fill="currentColor"/></svg></span><span class="sr">Watch Kairali on YouTube</span></a>
  <div class="sb-copy"><p class="kicker">Stories from the ground</p><h2>Real people. <em>Real impact.</em></h2>
    <blockquote><p>“Kairali is not just an organization; it's a trusted partner dedicated to the well-being and prosperity of farmers.”</p><cite>Mukundan, Farmer</cite></blockquote>
    <a class="btn btn-clay" href="impact/success-stories.html">View all stories ${icon("arrow")}</a></div>
  <div class="sb-rail-wrap"><div class="rail-ctrl light" data-for="story-rail">${arrowBtns("stories")}</div>
  <div class="rail" id="story-rail" tabindex="0" aria-label="Videos and features — scroll sideways"><ul class="rail-track">${[
    ["Kairali TV — Snehadharam", "Kairali TV: Snehadharam feature", "https://www.youtube.com/@kairaliagriculture", true],
    ["Carbon Credit Project", "Carbon Credit Project channel", "https://www.youtube.com/@carboncreditproject", true],
    ["Liquid Tree inauguration", "Liquid Tree inauguration", "green-initiatives/liquid-tree.html", false],
    ["Gold Standard, Geneva", "At Gold Standard, Geneva", "impact/csr-partnerships.html", false],
    ["Vayalar Karmasreshta Award", "Vayalar Karmasreshta Award 2024", "impact/awards-recognition.html", false],
  ].map(([im, t, h, vid]) => `<li><a class="sthumb" href="${h}"${vid ? ' target="_blank" rel="noopener"' : ""}><span class="st-img">${imgTag(IMG[im])}${vid ? `<span class="st-play" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5l12 7-12 7z" fill="currentColor"/></svg></span>` : ""}</span><span>${t}${vid ? ' <small>(video)</small>' : ""}</span></a></li>`).join("")}</ul></div></div>
</div></section>`;

  /* ---- 8. moving film strip of Kairali moments ---- */
  const moments = ["50th branch inauguration", "Gold Standard, Geneva", "Vayalar Karmasreshta Award", "Climate Agro inauguration", "NCUI MoU signing", "Liquid Tree inauguration", "Jawaharlal Nehru Excellence Award 2026", "Meeting with IFFCO Chairman", "50th branch — lamp lighting", "Best Environmental Activist Award", "Gold Standard, Geneva (2)", "Kairali TV — Snehadharam"];
  const strip2 = (list, hidden) => list.map((c) => `<li${hidden ? ' aria-hidden="true"' : ""}><figure>${imgTag(IMG[c])}<figcaption>${IMG[c].alt}</figcaption></figure></li>`).join("");
  const film = `<section class="section filmstrip"><div class="container sec-head row"><div><p class="kicker">Moments from Kairali</p><h2>Milestones, <em>in pictures</em></h2></div><div class="fs-actions"><button type="button" class="btn btn-ghost fs-toggle" aria-pressed="false">Pause</button><a class="link-arrow" href="media/photo-gallery.html">Photo gallery ${icon("arrow")}</a></div></div>
  <div class="fs-viewport" tabindex="0" aria-label="Kairali photo strip"><ul class="fs-track">${strip2(moments, false)}${strip2(moments, true)}</ul></div></section>`;

  /* ---- 9. news, partners, join (kept) ---- */
  const tail = `
<section class="section"><div class="container"><div class="sec-head row"><div><p class="kicker">Latest</p><h2>News <em>&amp; events</em></h2></div><a class="link-arrow" href="media/news-events.html">All news ${icon("arrow")}</a></div>
  <div class="news-cards">${news.map((n, i) => `<article class="news-card">${ph(["50th branch inauguration", "NCUI MoU signing", "Jawaharlal Nehru Excellence Award 2026"][i], "wide")}<div><span class="tag">${n.tag}</span><span class="news-date">${n.d}</span><h4>${n.title}</h4></div></article>`).join("")}</div></div></section>
<section class="section quote-band"><div class="container qb-grid">
  <div class="qb-msg">${ph("Portrait — Sri. Asokan K. V., Chairman", "arch")}<div><p class="kicker">From the Chairman</p><blockquote><p>“Our mission is to empower farming communities — providing essential support, creating opportunities, and working together towards a brighter, more prosperous future.”</p><cite>Sri. Asokan K. V., Chairman</cite></blockquote><a class="link-arrow" href="about/leadership.html">Read the full message ${icon("arrow")}</a></div></div>
  <div class="qb-story partners-in"><p class="kicker">Working alongside</p><ul class="partner-row">${["Gold Standard, Geneva", "National Cooperative Union of India", "IFFCO", "Ministry of Cooperation, Govt. of India"].map((x) => `<li>${x}</li>`).join("")}</ul></div>
</div></section>
<section class="join"><div class="container"><div><h2>Grow <em>with Kairali</em></h2><p>Join a growing community of farmers and rural entrepreneurs — with contribution schemes, insurance and training built around you.</p></div><div class="cta-btns"><a class="btn btn-clay btn-lg" href="membership/become-a-member.html">Become a Member</a><a class="btn btn-light btn-lg" href="membership/contribution-schemes.html">See contribution schemes</a></div></div></section>`;

  const body = hero + strip + about + workRail + green + prodRail + stories + film + tail;
  return shell({ title: "Kairali — Farmer-owned agriculture cooperative", root, active: "", body, home: true, desc: "Kairali Agriculture Multi State Co-operative Society Ltd. — creating opportunities in the agriculture sector." });
}

/* ---------------------------------------------------------------- write */
function write(rel, html) {
  const f = path.join(OUT, rel);
  fs.mkdirSync(path.dirname(f), { recursive: true });
  fs.writeFileSync(f, html);
}
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(path.join(OUT, "assets"), { recursive: true });
fs.copyFileSync(path.join(__dirname, "src/style.css"), path.join(OUT, "assets/style.css"));
fs.copyFileSync(path.join(__dirname, "src/main.js"), path.join(OUT, "assets/main.js"));
fs.cpSync(path.join(__dirname, "src/img"), path.join(OUT, "assets/img"), { recursive: true });
fs.writeFileSync(path.join(OUT, "assets/catalog.js"), "window.KAIRALI = " + JSON.stringify({
  products: products.map(({ id, name, price, mrp, size, img, brand, desc, long, features, uses, src, big, cat, draft }) => { const loc = resolveImg(img); const bl = resolveImg(big); return { id, name, price, mrp, size, cat, desc, long, features, uses, src, draft, img: loc ? "assets/img/" + loc : img, big: bl ? "assets/img/" + bl : big, bigLocal: !!bl, local: !!loc, brand: brands[brand].label }; }),
  whatsapp: "918078900222", email: "info@kairalimscs.com",
}) + ";");
write("index.html", homePage());
sections.forEach((s) => write(`${s.key}/index.html`, sectionIndex(s)));
Object.values(pages).forEach((p) => write(`${p.section}/${p.slug}.html`, subPage(p)));
fs.writeFileSync(path.join(__dirname, "remote-images.json"), JSON.stringify([...REMOTE], null, 1));
const nLocal = [...REMOTE].filter((u) => fs.existsSync(path.join(KDIR, localName(u)))).length;
console.log(`Kairali photos: ${nLocal}/${REMOTE.size} saved locally${nLocal < REMOTE.size ? " — run \`node fetch-images.js\` then build again to save the rest" : ""}`);
console.log(`Built ${1 + sections.length + Object.keys(pages).length} pages → site/  (${branches.all.length} branches: ${branches.kerala.length} Kerala + ${branches.tamilnadu.length} Tamil Nadu)`);
