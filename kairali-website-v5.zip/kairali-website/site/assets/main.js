/* Kairali sample site — small progressive-enhancement script. No dependencies. */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var body = document.body;

  /* mobile menu + touch-friendly mega menu */
  var toggle = $(".menu-toggle");
  if (toggle) {
    toggle.addEventListener("click", function () {
      var open = body.classList.toggle("menu-open");
      toggle.setAttribute("aria-expanded", String(open));
    });
  }
  $$(".has-mega > .nav-top").forEach(function (a) {
    a.addEventListener("click", function (e) {
      var mobile = window.matchMedia("(max-width: 920px)").matches;
      var li = a.parentElement;
      if (mobile && !li.classList.contains("open")) {
        e.preventDefault();
        $$(".has-mega.open").forEach(function (o) { o.classList.remove("open"); });
        li.classList.add("open");
        a.setAttribute("aria-expanded", "true");
      }
    });
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") { body.classList.remove("menu-open"); $$(".has-mega.open").forEach(function (o) { o.classList.remove("open"); }); }
  });

  /* review mode: reveals the "pending from Kairali" notes (remembered per browser) */
  var rt = $(".review-toggle");
  function setReview(on) {
    body.classList.toggle("review-on", on);
    if (rt) { rt.setAttribute("aria-pressed", String(on)); rt.lastElementChild.textContent = on ? "Review mode: on" : "Review mode"; }
    try { localStorage.setItem("kairali-review", on ? "1" : "0"); } catch (e) {}
  }
  var saved = false;
  try { saved = localStorage.getItem("kairali-review") === "1"; } catch (e) {}
  if (/[?&]review=1/.test(location.search)) saved = true;
  setReview(saved);
  if (rt) rt.addEventListener("click", function () { setReview(!body.classList.contains("review-on")); });

  /* count-up stats */
  var counters = $$("[data-count]");
  function run(el) {
    var end = parseInt(el.getAttribute("data-count"), 10), suf = el.getAttribute("data-suffix") || "", t0 = null;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    function step(t) {
      if (!t0) t0 = t;
      var p = Math.min((t - t0) / 1400, 1), v = Math.floor(end * (1 - Math.pow(1 - p, 3)));
      el.textContent = v.toLocaleString("en-IN") + (p === 1 ? suf : "");
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  /* scroll reveal + counters */
  $$(".card, .product, .p-card, .news-card, .timeline li, .steps li, .sdg-tile, .dl-group, .faq details").forEach(function (el) { el.classList.add("reveal"); });
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add("in");
        if (en.target.hasAttribute("data-count")) run(en.target);
        io.unobserve(en.target);
      });
    }, { threshold: 0.15 });
    $$(".reveal, [data-count]").forEach(function (el) { io.observe(el); });
  } else {
    $$(".reveal").forEach(function (el) { el.classList.add("in"); });
  }

  /* branch directory filters */
  var grid = $("#branch-grid");
  if (grid) {
    var q = $("#branch-q"), st = $("#branch-state"), di = $("#branch-district"), n = $("#branch-n");
    var cards = $$(".branch", grid), opts = $$("option[data-state]", di);
    function apply() {
      var text = q.value.trim().toLowerCase(), s = st.value, d = di.value, shown = 0;
      opts.forEach(function (o) { o.hidden = !!s && o.getAttribute("data-state") !== s; });
      if (d && s && di.selectedOptions[0] && di.selectedOptions[0].getAttribute("data-state") !== s) { di.value = ""; d = ""; }
      cards.forEach(function (c) {
        var ok = (!s || c.dataset.state === s) && (!d || c.dataset.district === d) && (!text || c.dataset.text.indexOf(text) > -1);
        c.hidden = !ok; if (ok) shown++;
      });
      n.textContent = shown;
    }
    [q, st, di].forEach(function (el) { el.addEventListener("input", apply); el.addEventListener("change", apply); });
  }

  /* sample enquiry form (front-end only) */
  var form = $("#enquiry-form");
  if (form) form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (!form.checkValidity()) { form.reportValidity(); return; }
    $(".form-note", form).hidden = false; form.reset();
  });

  /* ---------------- basket (stored in this browser only) ---------------- */
  var DATA = window.KAIRALI || { products: [] };
  var cs = document.querySelector('script[src$="assets/catalog.js"]');
  var ROOT = cs ? cs.getAttribute("src").replace("assets/catalog.js", "") : "";
  DATA.products.forEach(function (p) { if (p.local) { p.img = ROOT + p.img; p.local = false; } if (p.bigLocal) { p.big = ROOT + p.big; p.bigLocal = false; } });
  var byId = {}; DATA.products.forEach(function (p) { byId[p.id] = p; });
  var KEY = "kairali-basket";
  var basket = {};
  try { basket = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch (e) { basket = {}; }
  Object.keys(basket).forEach(function (id) { if (!byId[id]) delete basket[id]; });
  function save() { try { localStorage.setItem(KEY, JSON.stringify(basket)); } catch (e) {} }
  function count() { return Object.keys(basket).reduce(function (a, id) { return a + basket[id]; }, 0); }
  var inr = function (n) { return "₹" + n.toLocaleString("en-IN"); };
  var esc = function (t) { var d = document.createElement("div"); d.textContent = t; return d.innerHTML; };

  var bBtn = $(".basket-btn"), drawer = $("#basket"), scrim = $(".basket-scrim"), toast = $(".toast"), lastFocus = null, toastT;
  function showToast(html) {
    if (!toast) return;
    toast.innerHTML = html; toast.hidden = false;
    clearTimeout(toastT); toastT = setTimeout(function () { toast.hidden = true; }, 2600);
  }
  function render() {
    var n = count(), cEl = $(".basket-count");
    if (cEl) { cEl.textContent = n; cEl.classList.toggle("zero", n === 0); }
    if (!drawer) return;
    var ids = Object.keys(basket), list = $(".basket-list", drawer);
    drawer.classList.toggle("is-empty", ids.length === 0);
    list.innerHTML = ids.map(function (id) {
      var p = byId[id], q = basket[id];
      return '<li data-id="' + id + '"><img src="' + p.img + '" alt="" onerror="this.style.visibility=\'hidden\'"><div><strong>' + esc(p.name) + '</strong><small>' + esc(p.brand) + (p.size ? " · " + esc(p.size) : "") + '</small><br><small>' + (p.mrp ? inr(p.mrp) + " each" : "Price confirmed on enquiry") + '</small><br><button type="button" class="b-remove">Remove</button></div><div class="qty" role="group" aria-label="Quantity for ' + esc(p.name) + '"><button type="button" class="b-minus" aria-label="Decrease">−</button><span>' + q + '</span><button type="button" class="b-plus" aria-label="Increase">+</button></div></li>';
    }).join("");
    var priced = 0, unpriced = 0;
    ids.forEach(function (id) { if (byId[id].mrp) priced += byId[id].mrp * basket[id]; else unpriced += basket[id]; });
    $(".basket-sum", drawer).innerHTML = '<div class="total"><span>Estimated total</span><span>' + inr(priced) + '</span></div>' +
      (unpriced ? '<p>+ ' + unpriced + ' item' + (unpriced > 1 ? "s" : "") + ' with price confirmed on enquiry.</p>' : "") +
      '<p>MRP shown. Final price is confirmed by Kairali.</p>';
  }
  function add(id, q) {
    if (!byId[id]) return;
    basket[id] = Math.min(99, (basket[id] || 0) + q); save(); render();
    if (bBtn) { bBtn.classList.remove("bump"); void bBtn.offsetWidth; bBtn.classList.add("bump"); }
    showToast("Added <em>" + esc(byId[id].name) + "</em> × " + q + " to your basket");
  }
  function openBasket() {
    if (!drawer) return;
    lastFocus = document.activeElement;
    drawer.hidden = false; scrim.hidden = false; body.style.overflow = "hidden";
    if (bBtn) bBtn.setAttribute("aria-expanded", "true");
    $(".basket-close", drawer).focus();
  }
  function closeBasket() {
    if (!drawer || drawer.hidden) return;
    drawer.hidden = true; scrim.hidden = true; body.style.overflow = "";
    if (bBtn) bBtn.setAttribute("aria-expanded", "false");
    if (lastFocus) lastFocus.focus();
  }
  if (bBtn) bBtn.addEventListener("click", openBasket);
  if (scrim) scrim.addEventListener("click", closeBasket);
  if (drawer) {
    $(".basket-close", drawer).addEventListener("click", closeBasket);
    drawer.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeBasket();
      if (e.key === "Tab") { /* keep focus inside the drawer */
        var f = $$("button, input, a[href]", drawer).filter(function (el) { return el.offsetParent !== null; });
        if (!f.length) return;
        if (e.shiftKey && document.activeElement === f[0]) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === f[f.length - 1]) { e.preventDefault(); f[0].focus(); }
      }
    });
    $(".basket-list", drawer).addEventListener("click", function (e) {
      var li = e.target.closest("li"); if (!li) return; var id = li.getAttribute("data-id");
      if (e.target.closest(".b-plus")) basket[id] = Math.min(99, basket[id] + 1);
      else if (e.target.closest(".b-minus")) { basket[id]--; if (basket[id] < 1) delete basket[id]; }
      else if (e.target.closest(".b-remove")) delete basket[id];
      else return;
      save(); render();
    });
    var bform = $(".basket-form", drawer), via = "whatsapp";
    $$("[data-via]", bform).forEach(function (b) { b.addEventListener("click", function () { via = b.getAttribute("data-via"); }); });
    bform.addEventListener("submit", function (e) {
      e.preventDefault();
      var err = $(".form-err", bform);
      if (!bform.checkValidity()) { err.hidden = false; var bad = $(":invalid", bform); if (bad) bad.focus(); return; }
      err.hidden = true;
      var f = bform.elements, lines = ["Order enquiry — Kairali products", ""];
      Object.keys(basket).forEach(function (id) { var p = byId[id]; lines.push("• " + p.name + (p.size ? " (" + p.size + ")" : "") + " × " + basket[id] + (p.mrp ? " — MRP " + inr(p.mrp * basket[id]) : "")); });
      lines.push("", "Name: " + f.name.value, "Phone: " + f.phone.value, "Branch / address: " + f.where.value);
      var text = lines.join("\n");
      var url = via === "email"
        ? "mailto:" + DATA.email + "?subject=" + encodeURIComponent("Product order enquiry — " + f.name.value) + "&body=" + encodeURIComponent(text)
        : "https://wa.me/" + DATA.whatsapp + "?text=" + encodeURIComponent(text);
      window.open(url, "_blank", "noopener");
      showToast("Your order is ready to send — <em>finish it in " + (via === "email" ? "your email app" : "WhatsApp") + "</em>");
    });
  }
  $$(".product").forEach(function (card) {
    var input = $(".qty input", card);
    if (!input) return;
    var clamp = function (v) { v = parseInt(v, 10); return isNaN(v) ? 1 : Math.max(1, Math.min(99, v)); };
    $(".q-minus", card).addEventListener("click", function () { input.value = clamp(input.value - 1); });
    $(".q-plus", card).addEventListener("click", function () { input.value = clamp(+input.value + 1); });
    input.addEventListener("change", function () { input.value = clamp(input.value); });
    var btn = $(".add-basket", card);
    btn.addEventListener("click", function () {
      add(btn.getAttribute("data-id"), clamp(input.value)); input.value = 1;
      btn.classList.add("added"); var t = btn.lastChild.textContent; btn.lastChild.textContent = " Added";
      setTimeout(function () { btn.classList.remove("added"); btn.lastChild.textContent = t; }, 1400);
    });
  });
  render();

  /* ---------------- shop filters ---------------- */
  var shopQ = $("#shop-q");
  if (shopQ) {
    var chipsB = $$(".chip-btn"), cardsP = $$(".shop .product"), brandSel = "";
    function applyShop() {
      var t = shopQ.value.trim().toLowerCase(), n = 0;
      cardsP.forEach(function (c) { var ok = (!brandSel || c.dataset.brand === brandSel) && (!t || c.dataset.text.indexOf(t) > -1); c.hidden = !ok; if (ok) n++; });
      $("#shop-n").textContent = n; $(".shop-empty").hidden = n > 0;
    }
    chipsB.forEach(function (b) { b.addEventListener("click", function () {
      brandSel = b.getAttribute("data-brand");
      chipsB.forEach(function (x) { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", String(x === b)); });
      applyShop();
    }); });
    shopQ.addEventListener("input", applyShop);
  }

  /* ---------------- gallery lightbox ---------------- */
  var lb = $(".lightbox");
  if (lb && lb.showModal) {
    $$(".g-item").forEach(function (g) { g.addEventListener("click", function () {
      $("img", lb).src = g.getAttribute("data-full"); $("img", lb).alt = g.getAttribute("data-cap");
      $(".lb-cap", lb).textContent = g.getAttribute("data-cap"); lb.showModal();
    }); });
    $(".lb-close", lb).addEventListener("click", function () { lb.close(); });
    lb.addEventListener("click", function (e) { if (e.target === lb) lb.close(); });
  }

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------- hero slider ---------------- */
  $$(".hero-slider").forEach(function (hs) {
    var slides = $$(".hs-slide", hs), dots = $$(".hs-dot", hs), cnt = $(".hs-count strong", hs), pauseBtn = $(".hs-pause", hs);
    var i = 0, n = slides.length, dur = parseInt(hs.getAttribute("data-autoplay"), 10) || 7000, timer = null;
    var userPaused = reduce, hoverPaused = false;
    hs.style.setProperty("--dur", dur + "ms");
    if (reduce) hs.classList.add("no-auto");
    function go(k) {
      i = (k + n) % n;
      slides.forEach(function (sl, j) {
        var on = j === i; sl.classList.toggle("is-on", on); sl.setAttribute("aria-hidden", String(!on));
        $$("a,button", sl).forEach(function (a) { if (on) a.removeAttribute("tabindex"); else a.setAttribute("tabindex", "-1"); });
      });
      dots.forEach(function (d, j) { d.classList.remove("is-on"); void d.offsetWidth; d.classList.toggle("is-on", j === i); d.setAttribute("aria-current", j === i ? "true" : "false"); });
      cnt.textContent = (i + 1 < 10 ? "0" : "") + (i + 1);
      schedule();
    }
    function schedule() { clearTimeout(timer); if (!userPaused && !hoverPaused) timer = setTimeout(function () { go(i + 1); }, dur); }
    function setPaused(p) { userPaused = p; hs.classList.toggle("paused", p); pauseBtn.setAttribute("aria-pressed", String(p)); pauseBtn.setAttribute("aria-label", p ? "Play slideshow" : "Pause slideshow"); schedule(); }
    $(".hs-arrow.next", hs).addEventListener("click", function () { go(i + 1); });
    $(".hs-arrow.prev", hs).addEventListener("click", function () { go(i - 1); });
    dots.forEach(function (d, j) { d.addEventListener("click", function () { go(j); }); });
    pauseBtn.addEventListener("click", function () { setPaused(!userPaused); });
    hs.addEventListener("mouseenter", function () { hoverPaused = true; hs.classList.add("paused"); clearTimeout(timer); });
    hs.addEventListener("mouseleave", function () { hoverPaused = false; if (!userPaused) hs.classList.remove("paused"); go(i); });
    hs.addEventListener("focusin", function () { hoverPaused = true; clearTimeout(timer); });
    hs.addEventListener("focusout", function () { hoverPaused = false; schedule(); });
    hs.addEventListener("keydown", function (e) { if (e.key === "ArrowRight") go(i + 1); if (e.key === "ArrowLeft") go(i - 1); });
    var x0 = null;
    hs.addEventListener("touchstart", function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    hs.addEventListener("touchend", function (e) { if (x0 === null) return; var dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 50) go(i + (dx < 0 ? 1 : -1)); x0 = null; });
    document.addEventListener("visibilitychange", function () { if (document.hidden) clearTimeout(timer); else schedule(); });
    if (reduce) { hs.classList.add("paused"); pauseBtn.setAttribute("aria-pressed", "true"); }
    schedule();
  });

  /* ---------------- horizontal rails: arrows, drag, keyboard ---------------- */
  $$(".rail").forEach(function (rail) {
    var ctrl = $('.rail-ctrl[data-for="' + rail.id + '"]');
    var prev = ctrl && $(".prev", ctrl), next = ctrl && $(".next", ctrl);
    var step = function () { return Math.max(240, rail.clientWidth * 0.8); };
    function upd() {
      if (!prev) return;
      prev.disabled = rail.scrollLeft < 8;
      next.disabled = rail.scrollLeft + rail.clientWidth > rail.scrollWidth - 8;
    }
    if (prev) {
      prev.addEventListener("click", function () { rail.scrollBy({ left: -step(), behavior: reduce ? "auto" : "smooth" }); });
      next.addEventListener("click", function () { rail.scrollBy({ left: step(), behavior: reduce ? "auto" : "smooth" }); });
    }
    rail.addEventListener("scroll", upd, { passive: true }); window.addEventListener("resize", upd); upd();
    rail.addEventListener("keydown", function (e) {
      if (e.target !== rail) return;
      if (e.key === "ArrowRight") { e.preventDefault(); rail.scrollBy({ left: step() }); }
      if (e.key === "ArrowLeft") { e.preventDefault(); rail.scrollBy({ left: -step() }); }
    });
    /* mouse drag-to-scroll (touch already scrolls natively) */
    var down = false, sx = 0, sl = 0, moved = 0;
    rail.addEventListener("mousedown", function (e) {
      if (e.button !== 0 || e.target.closest("button, input")) return;
      down = true; moved = 0; sx = e.pageX; sl = rail.scrollLeft; e.preventDefault();
    });
    window.addEventListener("mousemove", function (e) {
      if (!down) return; var dx = e.pageX - sx; moved = Math.abs(dx);
      if (moved > 5) rail.classList.add("dragging");
      rail.scrollLeft = sl - dx;
    });
    window.addEventListener("mouseup", function () {
      if (!down) return; down = false;
      setTimeout(function () { rail.classList.remove("dragging"); }, 0);
    });
    rail.addEventListener("click", function (e) { if (moved > 5) { e.preventDefault(); e.stopPropagation(); moved = 0; } }, true);
  });

  /* ---------------- film strip pause ---------------- */
  $$(".filmstrip").forEach(function (fs) {
    var b = $(".fs-toggle", fs); if (!b) return;
    if (reduce) { b.hidden = true; return; }
    b.addEventListener("click", function () {
      var p = fs.classList.toggle("paused"); b.setAttribute("aria-pressed", String(p)); b.textContent = p ? "Play" : "Pause";
    });
  });

  /* ---------------- product details dialog ---------------- */
  var pm = $(".pmodal");
  if (pm && pm.showModal) {
    var pmImg = $(".pm-img img", pm), pmQty = $(".pm-body .qty input", pm), pmAdd = $(".pm-add", pm), cur = null;
    function fillList(ul, items, chip) { ul.innerHTML = (items || []).map(function (t) { return chip ? "<li>" + esc(t) + "</li>" : '<li><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="M4 12l5 5L20 6"/></svg><span>' + esc(t) + "</span></li>"; }).join(""); ul.parentNode.hidden = !(items && items.length); }
    function openProduct(id) {
      var p = byId[id]; if (!p) return; cur = id;
      $(".pm-img", pm).classList.remove("img-fail");
      pmImg.alt = p.name; pmImg.dataset.fb = p.img; pmImg.src = p.big || p.img;
      $(".pm-brand", pm).textContent = p.brand + (p.cat ? " · " + p.cat : "");
      $("#pm-title").textContent = p.name;
      $(".pm-long", pm).textContent = p.long || p.desc;
      fillList($(".pm-feat ul", pm), p.features, false); fillList($(".pm-uses ul", pm), p.uses, true);
      $(".pm-lists", pm).hidden = !(p.features || p.uses);
      $(".pm-draft", pm).hidden = !p.draft;
      $(".pm-meta", pm).innerHTML = (p.price ? '<span class="price"><small>MRP</small> ' + esc(p.price) + "</span>" : '<span class="price na">Price on request</span>') + (p.size ? '<span class="size">' + esc(p.size) + "</span>" : "");
      var src = $(".pm-src", pm); if (p.src) { src.href = p.src; src.hidden = false; } else src.hidden = true;
      pmQty.value = 1; pm.showModal(); $(".pm-close", pm).focus();
    }
    pmImg.addEventListener("error", function () { if (pmImg.dataset.fb && pmImg.src.indexOf(pmImg.dataset.fb) < 0) { pmImg.src = pmImg.dataset.fb; } else { $(".pm-img", pm).classList.add("img-fail"); } });
    $$(".p-more").forEach(function (b) { b.addEventListener("click", function () { openProduct(b.getAttribute("data-id")); }); });
    $$(".product .product-img").forEach(function (im) { im.style.cursor = "zoom-in"; im.addEventListener("click", function () { openProduct(im.closest(".product").getAttribute("data-id")); }); });
    var clampQ = function (v) { v = parseInt(v, 10); return isNaN(v) ? 1 : Math.max(1, Math.min(99, v)); };
    $(".q-minus", pm).addEventListener("click", function () { pmQty.value = clampQ(pmQty.value - 1); });
    $(".q-plus", pm).addEventListener("click", function () { pmQty.value = clampQ(+pmQty.value + 1); });
    pmAdd.addEventListener("click", function () { add(cur, clampQ(pmQty.value)); pm.close(); });
    $(".pm-close", pm).addEventListener("click", function () { pm.close(); });
    pm.addEventListener("click", function (e) { if (e.target === pm) pm.close(); });
  }

  /* ---------------- news filter + current year ---------------- */
  $$("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });
  var nf = $(".news-filter");
  if (nf) {
    var nb = $$(".chip-btn", nf), items = $$(".news-item");
    nb.forEach(function (b) { b.addEventListener("click", function () {
      var t = b.getAttribute("data-tag");
      nb.forEach(function (x) { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", String(x === b)); });
      items.forEach(function (it) { it.hidden = !!t && it.getAttribute("data-tag") !== t; });
    }); });
  }
})();
