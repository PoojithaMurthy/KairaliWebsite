// One-time helper: downloads Kairali's own photos (listed by build.js in remote-images.json)
// into src/img/kairali so the site works offline and doesn't depend on hotlinking.
//   node build.js && node fetch-images.js && node build.js
const fs = require("fs"), path = require("path"), https = require("https");
const list = JSON.parse(fs.readFileSync(path.join(__dirname, "remote-images.json"), "utf8"));
const dir = path.join(__dirname, "src/img/kairali");
fs.mkdirSync(dir, { recursive: true });
const localName = (url) => decodeURIComponent((url.split("/uploads/")[1] || url.split("/").pop()).split("?")[0]).replace(/[^A-Za-z0-9._-]+/g, "_");
function get(url, file, hops = 0) {
  return new Promise((resolve) => {
    https.get(url, { headers: { "User-Agent": "Mozilla/5.0 (Kairali site build)", Referer: url.includes("wikimedia") ? "https://commons.wikimedia.org/" : "https://kairalimscs.com/" } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops < 4) { res.resume(); return resolve(get(new URL(res.headers.location, url).href, file, hops + 1)); }
      if (res.statusCode !== 200) { res.resume(); return resolve(`✗ ${res.statusCode} ${url}`); }
      const out = fs.createWriteStream(file); res.pipe(out); out.on("finish", () => resolve(`✓ ${path.basename(file)}`));
    }).on("error", (e) => resolve(`✗ ${e.message} ${url}`));
  });
}
(async () => {
  let ok = 0;
  for (const url of list) {
    const file = path.join(dir, localName(url));
    if (fs.existsSync(file)) { ok++; continue; }
    const r = await get(url, file); if (r.startsWith("✓")) ok++; else console.log(r);
  }
  console.log(`${ok}/${list.length} Kairali photos saved in src/img/kairali. Now run: node build.js`);
})();
