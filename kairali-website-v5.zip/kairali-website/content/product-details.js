// Detailed product copy — adapted from Kairali's own product pages on kairalimscs.com (Sept 2026).
// Facts, ingredients and uses are kept; marketing superlatives are trimmed. `src` links back to the original page.
// Health-related claims are Kairali's own and should be checked against FSSAI / labelling rules before launch.
const K = "https://kairalimscs.com/product/";

module.exports = {
  "virgin-plus-oil": {
    src: K + "virgin-plus-coconut-oil/",
    long: "Virgin Plus Extra Virgin Coconut Oil is extracted from fresh coconut milk through a chemical-free process, so the oil keeps its natural goodness. It is rich in vitamins, minerals and antioxidants, and makes an everyday oil for cooking as well as for skin and hair.",
    features: ["Extracted from fresh coconut milk", "Chemical-free process", "Naturally rich in vitamins, minerals and antioxidants"],
    uses: ["Everyday cooking", "Skin and hair care"],
  },
  "premium-oil": {
    src: K + "premium-coconut-oil/",
    long: "Premium Coconut Oil is cold-pressed from handpicked coconuts to keep its nutrient-rich profile. It is rich in medium-chain triglycerides (MCTs) and antioxidants, with a light texture and a delicate coconut aroma.",
    features: ["Cold-pressed from handpicked coconuts", "Rich in MCTs and antioxidants", "Light texture, delicate aroma"],
    uses: ["Cooking and baking", "Moisturising skin", "Conditioning hair"],
  },
  "coconut-chips": {
    src: K + "coconut-chips/",
    long: "Thin slices of premium coconut meat, toasted to bring out their natural sweetness and nutty aroma. A crunchy snack with healthy fats and fibre.",
    features: ["Thinly sliced coconut meat", "Toasted for a natural, nutty sweetness", "Source of healthy fats and fibre"],
    uses: ["Snack straight from the pack", "Topping for yoghurt or salads", "Add to your own recipes"],
    big: "https://kairalimscs.com/wp-content/uploads/2023/05/virgin-plus-tender-coconut-chips.jpeg",
  },
  "dc-powder": {
    src: K + "desiccated-coconut-powder/",
    long: "Made from 100% pure, finely grated coconut, with no artificial additives or preservatives. It adds a rich coconut flavour and texture to sweet and savoury dishes, and keeps well in the pantry.",
    features: ["100% pure, finely grated coconut", "No artificial additives or preservatives", "Long-lasting pantry staple"],
    uses: ["Cakes and cookies", "Curries", "Smoothies and garnishing"],
  },
  "chammanthi-podi": {
    src: K + "coconut-chamanthi-podi/",
    long: "A traditional Kerala condiment made from freshly grated coconut, aromatic spices and a blend of herbs. It has a balanced, lightly tangy and spicy taste, and is ready to use straight from the pack.",
    features: ["Freshly grated coconut, spices and herbs", "Traditional homemade chammanthi taste", "Ready to use"],
    uses: ["With rice", "With idli or dosa", "As a spread on bread"],
  },
  "hair-cream": {
    src: K + "natural-hair-cream/",
    long: "A lightweight hair cream made with plant-based oils, vitamins and proteins. It hydrates and protects the hair, leaving it smooth and soft. It is made without harsh chemicals or artificial fragrances, is gentle on the scalp and suits all hair types, including dry, damaged or frizzy hair.",
    features: ["Plant-based oils, vitamins and proteins", "No harsh chemicals or artificial fragrance", "Lightweight, for all hair types"],
    uses: ["Daily conditioning", "Dry, damaged or frizzy hair"],
    big: "https://kairalimscs.com/wp-content/uploads/2023/06/Hair-Cream-e1685962363453.png",
  },
  "green-pad": {
    src: K + "green-pad/",
    long: "GreenPad is an herbal sanitary napkin with an eco-conscious approach. It is infused with herbal extracts — mugwort, angelica and fuzi — known for their soothing properties, and is free from harsh chemicals and synthetic fragrance. Each pack holds 10 pads in XXL (350 mm) and XL (280 mm) sizes.",
    features: ["Herbal blend: mugwort, angelica and fuzi", "No harsh chemicals or synthetic fragrance", "Made in an ISO 9001:2015 facility", "10 pads: XXL 350 mm and XL 280 mm"],
    uses: ["Everyday menstrual care"],
  },
  "stain-remover": {
    src: K + "stain-remover-for-clothes/",
    long: "A plant-based stain remover for food, grease, oil, grass and other everyday stains. You can spray or pour it straight onto the stain before washing. Using plant-based ingredients means less environmental impact than conventional chemical cleaners.",
    features: ["Plant-based ingredients", "Works on food, grease, oil and grass stains", "Spray or pour application"],
    uses: ["Pre-treat stains before washing"],
    draft: false,
  },
  "forest-oil": {
    src: K + "forest-oil/",
    long: "A blend of botanical oils and plant extracts with a fresh, forest-inspired scent. It hydrates and softens the skin.",
    features: ["Blend of botanical oils and plant extracts", "Hydrates and softens skin", "Fresh, natural aroma"],
    uses: ["Massage", "Aromatherapy", "Everyday moisturising"],
    draft: false,
  },
  "amla-powder": {
    src: K + "amla-powder/",
    long: "Powdered Indian gooseberry (amla), naturally rich in vitamin C and antioxidants. It is traditionally used in hair packs to strengthen roots and refresh the scalp.",
    features: ["Pure Indian gooseberry powder", "Naturally rich in vitamin C and antioxidants"],
    uses: ["Hair mask", "Skincare packs"],
    draft: false,
  },
  "dry-fruits-honey": {
    src: K + "dry-fruits-honey/",
    long: "Honey blended with dry fruits for a nutrient-rich, energy-giving spoonful.",
    features: ["Honey with dry fruits", "Nutrient-rich energy boost", "Natural antioxidants"],
    uses: ["By the spoon", "On toast or with breakfast"],
    draft: false,
  },
  "jamun-crush": {
    src: K + "jamun-crush/",
    long: "A crush made with natural ingredients and the authentic taste of jamun (Indian blackberry). Mix it with water for a refreshing drink.",
    features: ["Authentic jamun flavour", "Natural ingredients"],
    uses: ["Mix with chilled water or soda"],
    draft: false,
  },
  "mango-crush": {
    src: K + "alphonso-mango-crush/",
    long: "A rich, thick crush made from Alphonso mangoes and natural ingredients.",
    features: ["Alphonso mango", "Rich, thick consistency", "Natural ingredients"],
    uses: ["Juices and milkshakes", "Desserts"],
    draft: false,
  },
  "passion-crush": {
    src: K + "passion-fruit-crush/",
    long: "A crush made from passion fruit and natural ingredients, with a tropical aroma.",
    features: ["Exotic passion-fruit flavour", "Tropical aroma", "Natural ingredients"],
    uses: ["Mix with chilled water", "Mocktails"],
    draft: false,
  },
};
