// Kairali website — navigation + page content (draft, from the Content Document v3).
// Block types are rendered by build.js. `pending` blocks are things the NGO still needs to confirm;
// they are hidden by default and shown in yellow when "Review mode" is switched on.

const sections = [
  { key: "about", label: "About Us", icon: "leaf", lead: "Who Kairali is, its purpose, and how it is governed." },
  { key: "our-work", label: "Our Work", icon: "sprout", lead: "The core activities Kairali carries out for its farmer-members and communities." },
  { key: "green-initiatives", label: "Green Initiatives", icon: "sun", lead: "Environmental and sustainability projects, built around and for our farmer community." },
  { key: "products", label: "Products", icon: "jar", lead: "Consumer goods crafted from Kairali's farms and cooperative network." },
  { key: "impact", label: "Impact", icon: "globe", lead: "The difference our work makes — for farmers, the environment, and the wider cooperative movement." },
  { key: "media", label: "Media & Resources", icon: "camera", lead: "Photos, videos and downloadable resources from across Kairali's work." },
  { key: "membership", label: "Membership", icon: "users", lead: "Everything a farmer or supporter needs to join and benefit from the Kairali cooperative." },
  { key: "contact", label: "Contact", icon: "pin", lead: "How to reach Kairali's head office and branch network." },
];

const pages = {};
const add = (section, slug, label, icon, one, blocks) => { pages[`${section}/${slug}`] = { section, slug, label, icon, one, blocks }; };

/* ========================= ABOUT US ========================= */
add("about", "about-kairali", "About Kairali", "leaf", "An introduction to Kairali — who we are, where we work, and what we do, at a glance.", [
  { t: "photoText", photo: "Kairali members at a community training session", body: [
    { t: "p", x: "Kairali Agriculture MSCS Ltd. is a pioneering multi-state cooperative society registered under the Ministry of Cooperation, Government of India, headquartered in Thrissur, Kerala, with operational centres across Kerala and Tamil Nadu." },
    { t: "p", x: "Dedicated to farmer empowerment, agricultural advancement and sustainable livelihoods, Kairali works to transform the agricultural landscape through eco-friendly and socio-economic initiatives — bringing farmers together so that no one faces the market, or the climate, alone." },
    { t: "kv", items: [["Registration", "MSCS/CR/1346/2022"], ["Headquarters", "Thrissur, Kerala"], ["Operating in", "Kerala and Tamil Nadu"]] },
  ]},
  { t: "h", x: "Our major areas of activity" },
  { t: "cards", cols: 3, items: [
    { icon: "wheat", title: "Agricultural & allied activities", text: "Farming support with dairy, poultry, fisheries and other allied livelihoods.", href: "our-work/agriculture-rural-livelihoods" },
    { icon: "coins", title: "Member financial & cooperative services", text: "Contribution schemes, insurance and social security for members.", href: "membership/member-benefits" },
    { icon: "jar", title: "FMCG & agricultural products", text: "Coconut, honey, home-care, herbal and everyday grocery products.", href: "products/index" },
    { icon: "sun", title: "Sustainable agriculture & green initiatives", text: "Carbon credits, Liquid Tree, BSFL waste-to-value and eco-farming.", href: "green-initiatives/index" },
    { icon: "tree", title: "Eco-farming & eco-tourism", text: "An integrated eco farm and farm-tourism experiences.", href: "green-initiatives/eco-farm-tourism" },
    { icon: "book", title: "Training & capacity building", text: "Awareness and skills programmes for members and stakeholders.", href: "our-work/training-capacity-building" },
  ]},
]);

add("about", "vision-mission", "Vision & Mission", "eye", "Our vision, mission, core philosophy and cooperative principles.", [
  { t: "split2", left: [
    { t: "callout", title: "Our Vision", x: "To provide financial support to struggling agricultural workers and contribute to the nation's growth in the agricultural sector. Through voluntary, goal-oriented efforts, we aspire to bring our farming community to the forefront of the nation while promoting equality, prosperity and inclusive development." },
    { t: "pending", x: "Two different Vision statements exist in the source documents (company profile vs. brochure v1.1). The brochure version is used here — please confirm the preferred, current wording." },
  ], right: [
    { t: "callout", title: "Our Mission", x: "To create opportunities in agriculture, resolve the difficulties faced by people working in the sector, and bring back the shine of traditional agriculture — by treating everyone as family." },
  ]},
  { t: "h", x: "What we strive to do" },
  { t: "ul", items: [
    "Implement innovative carbon-reduction projects that mitigate environmental impact and contribute to global climate action.",
    "Develop carbon-neutral eco-tourism and integrated eco-farming initiatives that promote sustainability, local culture and environmental awareness.",
    "Cultivate and market organic agricultural products that preserve soil health, biodiversity and long-term productivity.",
    "Promote agricultural and allied activities — including dairy, poultry and fisheries — alongside cooperative entrepreneurship and inclusive rural development.",
    "Craft plant-based home-care products that meet the demand for sustainable household solutions.",
    "Promote women's health and wellness through herbal sanitary products made from natural, sustainable resources.",
    "Champion the resurgence of nutritious, sustainable millet products.",
    "Harness the bounty of the coconut to create value-added products that support sustainable livelihoods.",
    "Empower farmers to take part in climate-smart agriculture and benefit from the emerging green economy, supported by ongoing training.",
  ]},
  { t: "pending", x: "Mission wording differs slightly across the company profile, Green Pad brochure and brochure v1.1. This list merges the most complete version — please confirm final wording." },
  { t: "h", x: "Core philosophy" },
  { t: "cards", cols: 3, items: [
    { icon: "shield", title: "Integrity", text: "Transparent governance and accountability to every farmer-member." },
    { icon: "leaf", title: "Quality", text: "Certified practices and products meeting national and international standards." },
    { icon: "hand", title: "Commitment", text: "Sustained, on-ground support for farming communities, season after season." },
  ]},
  { t: "h", x: "Our cooperative principles" },
  { t: "quote", x: "The Society remains committed to the cooperative principles of inclusive growth, mutual benefit, transparency and sustainable development.", by: "Kairali submission to NCUI" },
]);

add("about", "our-journey", "Our Journey", "route", "Key milestones in Kairali's growth since 2022.", [
  { t: "timeline", items: [
    { y: "2022", x: "Registered as a Multi State Cooperative Society under the Ministry of Cooperation, Government of India. Head office in Thrissur begins operations (17 July)." },
    { y: "2023", x: "First Annual Day celebrated in Thrissur (17 August); the branch network takes root." },
    { y: "2024", x: "Green Pad launched (2 March); Carbon Credit Project press launch (21 March); discussions with Gold Standard, Geneva (September); 12 new branches; several awards." },
    { y: "2025", x: "Global Indian Switzerland Business Achievement Award (March); new branches at Kadavanthra (Kochi) and a renovated Thrissur branch." },
    { y: "2026", x: "50th branch inaugurated; MoU signed with NCUI; Jawaharlal Nehru Excellence Award." },
  ]},
  { t: "pending", x: "The brochure's timeline (\"50th branch opened\" in 2026) and its stat tile (\"55+ branches\") do not quite line up, and the Global Indian Switzerland award is now dated March 2025 as on the live About page. The 17 July 2022 start date comes from the head-office page linked from the live Contact page (an external Wix site) — please confirm." },
]);

add("about", "leadership", "Leadership", "user", "A welcome message from our Chairman.", [
  { t: "photoText", photo: "Portrait — Sri. Asokan K. V., Chairman", flip: true, body: [
    { t: "h", x: "Sri. Asokan K. V." },
    { t: "p", x: "<strong>Chairman, Kairali Agriculture MSCS Ltd.</strong>" },
    { t: "quote", x: "I warmly welcome you to Kairali Agriculture Multi State Co-operative Society Ltd., an organisation dedicated to the welfare of farmers and the sustainable growth of agriculture." },
  ]},
  { t: "p", x: "Our mission is to empower farming communities — providing essential support, creating opportunities, and working together towards a brighter, more prosperous future. Through visionary initiatives such as our Carbon Credit Project, we promote eco-friendly practices and sustainable technologies while contributing to a healthier environment for generations to come." },
  { t: "p", x: "Our Kera Tech project creates value-added products from coconut, raising the value of agricultural produce and generating new opportunities for farmers. Through our Agriculture Farm Tourism programme, we celebrate rural life while creating additional income for farming communities." },
  { t: "p", x: "As we continue to grow, our commitment to farmers and sustainable agriculture remains unwavering. Together, we strive to nurture innovation, create opportunities, and contribute to the prosperity of India's agricultural sector." },
  { t: "p", x: "— Sri. Asokan K. V., Chairman" },
  { t: "pending", x: "Name style standardised to ‘Sri. Asokan K. V.’ everywhere (the live About page uses five spellings, including ‘Ashokan’). Please confirm the preferred form. Only the Chairman is named in any source document. If a full leadership team (Vice-Chairman, MD/CEO, Board) should appear, names, titles and photos are needed." },
]);

add("about", "registration-governance", "Registration & Governance", "shield", "Our legal registration, certifications and governance structure.", [
  { t: "kv", items: [["Legal name", "Kairali Agriculture Multi State Co-operative Society Ltd."], ["Registration No.", "MSCS/CR/1346/2022"], ["Registered under", "Ministry of Cooperation, Government of India"], ["Registered office", "Kovilakam Tower, Warriam Lane, Thekkemadom Road, Thrissur – 680001"]] },
  { t: "photo", x: "Certificate of Registration (scan)", ratio: "arch" },
  { t: "p", x: "<span class=\"cert-cap\">Certificate of Registration issued under the Multi-State Co-operative Societies Act, 2002 — Regd. No. MSCS/CR/1346/2022.</span>" },
  { t: "h", x: "Certifications" },
  { t: "ul", items: ["ISO 9001:2015 — Green Pad manufacturing facility"] },
  { t: "pending", x: "Only ISO 9001:2015 is legible on the certificate wall photographed at the Green Pad facility. Other certificates (issuing bodies, validity) are needed as clean scans. No organic-certification body (e.g. NPOP / Jaivik Bharat) is named anywhere despite the many 'organic' claims — please confirm." },
  { t: "h", x: "Governance" },
  { t: "p", x: "Kairali is governed as a multi-state cooperative society, guided by the cooperative principles of inclusive growth, mutual benefit, transparency and sustainable development." },
  { t: "pending", x: "No Board of Directors, committee structure or governance documents (bye-laws, AGM reports) are available. Recommended if this section should demonstrate institutional transparency." },
]);

/* ========================= OUR WORK ========================= */
add("our-work", "agriculture-rural-livelihoods", "Agriculture & Rural Livelihoods", "wheat", "Supporting farmers and rural communities through agriculture-based livelihood opportunities.", [
  { t: "p", x: "At the heart of Kairali's work is a commitment to agricultural and allied activities that create sustainable livelihoods for its farmer-members. From organic cultivation to market access and cooperative entrepreneurship, our programmes are designed to strengthen farming as a viable, dignified livelihood — bringing farmers together as a community rather than leaving them to face market and climate risks alone." },
  { t: "p", x: "We are also expanding into farmer-oriented value addition and marketing, helping members process and market their produce directly instead of selling raw produce alone — building on the value-addition already underway through Kera Tech and Bee Craft." },
  { t: "cards", cols: 3, items: [
    { icon: "wheat", title: "Organic & sustainable farming", text: "Practices that protect soil health and biodiversity." },
    { icon: "jar", title: "Value addition", text: "Coconut, honey and millet products that raise farm incomes.", href: "products/index" },
    { icon: "users", title: "Cooperative entrepreneurship", text: "Members as owners, not just suppliers." },
  ]},
  { t: "pending", x: "Beyond the initiatives documented elsewhere, no additional named livelihood programmes or farmer-count figures are available. Please share any others." },
]);

add("our-work", "allied-farming", "Allied Farming", "cow", "Diversifying farmer income through dairy, poultry, fisheries and other allied farming activities.", [
  { t: "p", x: "Poultry, dairy, fisheries and other allied farming activities form one of Kairali's major areas of activity, helping member-farmers diversify beyond crop farming into additional income streams." },
  { t: "cards", cols: 3, items: [
    { icon: "cow", title: "Dairy & cattle development", text: "Supporting members with cattle rearing and dairy income." },
    { icon: "egg", title: "Poultry farming", text: "Small-scale poultry as a steady supplementary livelihood." },
    { icon: "fish", title: "Fisheries & aquaculture", text: "Aquaculture that makes use of farm water resources." },
  ]},
  { t: "callout", title: "See it in practice", x: "This allied-farming work runs alongside our Integrated Eco Farm — a flagship demonstration site that brings organic cultivation, dairy, poultry and fisheries together in one closed-loop system.", href: "green-initiatives/integrated-eco-farm", cta: "Explore the Integrated Eco Farm" },
  { t: "pending", x: "Kairali's NCUI submission lists these activities both as a current major area of activity and as 'new & upcoming projects'. Please confirm the actual status of each (running now vs. planned), plus locations, scale and photos." },
]);

add("our-work", "member-cooperative-services", "Member & Cooperative Services", "coins", "An overview of the cooperative and financial services Kairali provides — full detail under Membership.", [
  { t: "p", x: "Kairali provides member-oriented financial and cooperative services, insurance and social security initiatives, and structured contribution schemes designed around the needs of farmer-members." },
  { t: "callout", title: "Everything for members, in one place", x: "Scheme terms, benefits, services and frequently asked questions are covered in full under Membership.", href: "membership/index", cta: "Go to Membership" },
]);

add("our-work", "training-capacity-building", "Training & Capacity Building", "book", "Ongoing skill-building and awareness programmes for members and stakeholders.", [
  { t: "p", x: "Kairali runs ongoing training, awareness and capacity-building programmes for its members and wider stakeholders — covering sustainable farming practices, climate change and carbon-reduction awareness, cooperative governance, and the economic opportunities of the green economy." },
  { t: "cards", cols: 2, items: [
    { icon: "sun", title: "Climate & carbon awareness", text: "Understanding carbon credits and low-carbon farming." },
    { icon: "wheat", title: "Sustainable farming practices", text: "Soil health, manure management, agroforestry and more." },
    { icon: "users", title: "Cooperative governance", text: "How a cooperative works and how members take part." },
    { icon: "coins", title: "Green-economy opportunities", text: "Turning sustainable practice into additional income." },
  ]},
  { t: "pending", x: "No programme calendar, session topics, trainer details, venues or participation numbers are available. A sample training calendar would let this page list real upcoming sessions." },
]);

/* ========================= GREEN INITIATIVES ========================= */
add("green-initiatives", "carbon-credit-project", "Carbon Credit Project", "sun", "Helping farmer-members earn additional income by adopting climate-smart, sustainable farming practices.", [
  { t: "p", x: "Global warming and climate change are the most alarming issues we face today. The Agriculture, Forestry and Other Land Use (AFOLU) sector contributes 25% of global anthropogenic carbon emissions; in India it accounts for around 8% of national GHG emissions but can contribute significantly to the country's net-zero ambition for 2070." },
  { t: "p", x: "Through the Carbon Credit Project, Kairali brings farmers together to adopt sustainable, climate-smart practices — and to earn from the carbon credits generated on their own land." },
  { t: "gallery", items: ["Carbon Credit Project", "Carbon Credit Project (2)", "Carbon Credit Project (3)"] },
  { t: "docs", title: "Carbon Credit Project brochures", files: [["Brochure — English", "Carbon Credit Project|Brochure — English"], ["Brochure — Malayalam", "Carbon Credit Project|Brochure — Malayalam"], ["Brochure — Tamil", "Carbon Credit Project|Brochure — Tamil"], ["Syllabus — English", "Carbon Credit Project|Syllabus — English"], ["Syllabus — Malayalam", "Carbon Credit Project|Syllabus — Malayalam"], ["Booklet — Malayalam", "Carbon Credit Project|Booklet — Malayalam"]] },
  { t: "p", x: "Videos about the project are on the <a href=\"https://www.youtube.com/@carboncreditproject\" target=\"_blank\" rel=\"noopener\">Carbon Credit Project YouTube channel</a>. Kairali’s main channel is <a href=\"https://www.youtube.com/@kairaliagriculture\" target=\"_blank\" rel=\"noopener\">@kairaliagriculture</a>." },
  { t: "h", x: "Strategies implemented" },
  { t: "chips", items: ["Better land use", "Manure & fertilizer management", "Prevent biomass burning", "Agroforestry", "Climate-smart farming", "Afforestation", "Better waste management", "Reduce enteric emissions", "Sustainable farming", "Clean development mechanisms"] },
  { t: "h", x: "What is there to gain?" },
  { t: "p", x: "Carbon credits put an economic value on the cost of polluting the air. Farmers receive cash incentives for the carbon they sequester in their lands — and along the way they restore soil health, adopt advanced intercropping and crop rotation, and help build awareness of carbon markets." },
  { t: "photoText", photo: "Deesan Farms, Meenakshipuram — model farm and training centre", body: [
    { t: "h", x: "Model farm: Deesan Farms" },
    { t: "p", x: "Deesan Farms in Meenakshipuram, Palakkad District, is the project's designated model farm and training centre." },
  ]},
  { t: "h", x: "Partners" },
  { t: "cards", cols: 2, items: [
    { icon: "globe", title: "Gold Standard, Geneva", text: "Gary Newcomer, General Manager of the International Investment Division, held discussions with the project team and offered full support and cooperation." },
    { icon: "handshake", title: "NCUI, New Delhi", text: "An MoU to strengthen cooperative-led work in sustainable agriculture, carbon reduction and green finance — highlighting Kairali's AGRONET app for farmer enrolment and carbon-credit tracking.", href: "impact/csr-partnerships" },
  ]},
  { t: "callout", title: "Join the movement", x: "Support team: +91 8590600720 · +91 8590600453 · admin@kairalimscs.com. Brochures, syllabi and booklets are in Resources & Downloads.", href: "media/resources-downloads", cta: "Get the brochures" },
  { t: "pending", x: "No figures exist for credits generated, tonnes of CO₂ sequestered, or farms/farmers enrolled. The AGRONET app appears only once (in the NCUI MoU text) — screenshots, features and store links would strengthen this page." },
]);

add("green-initiatives", "integrated-eco-farm", "Integrated Eco Farm", "tree", "A flagship model farm combining organic cultivation with dairy, poultry and fisheries in one closed-loop system.", [
  { t: "p", x: "Kairali's Integrated Eco Farm brings together organic cultivation, dairy, poultry and fisheries within a single, closed-loop farming system — designed to diversify farmer income, minimise waste, and demonstrate sustainable, low-carbon agriculture in practice." },
  { t: "p", x: "It is intended to serve as a training and demonstration site for member-farmers looking to adopt mixed farming alongside their existing crops." },
  { t: "cards", cols: 4, items: [
    { icon: "wheat", title: "Organic cultivation", text: "" }, { icon: "cow", title: "Dairy", text: "" }, { icon: "egg", title: "Poultry", text: "" }, { icon: "fish", title: "Fisheries", text: "" },
  ]},
  { t: "callout", title: "Part of a bigger picture", x: "The eco farm draws on Kairali's wider allied-farming activity.", href: "our-work/allied-farming", cta: "See Allied Farming" },
  { t: "pending", x: "Please confirm the current status (piloting vs. planning), location(s), scale and photos of the Integrated Eco Farm." },
]);

add("green-initiatives", "eco-farm-tourism", "Eco / Farm Tourism", "mountain", "Farm-tourism experiences that let visitors reconnect with organic farming and rural life.", [
  { t: "p", x: "Experience the wonders of nature, organic farming and rural charm. Kairali's Agriculture Farm Tourism invites visitors to escape the urban hustle and reconnect with the roots of sustainable farming." },
  { t: "cards", cols: 3, items: [
    { icon: "wheat", title: "Organic farming at its finest", text: "Wander through lush fields, savour chemical-free produce and learn about responsible farming." },
    { icon: "route", title: "Engaging farm tours", text: "Guided tours led by experienced agriculturists — crops, livestock and crop rotation." },
    { icon: "jar", title: "Farm-to-table meals", text: "Traditional recipes prepared with freshly harvested ingredients." },
    { icon: "home", title: "Rustic accommodation", text: "Cosy cottages and eco-friendly lodges amid serene landscapes." },
    { icon: "fish", title: "Farm activities", text: "Fishing, farming workshops, fruit and vegetable picking." },
    { icon: "leaf", title: "Relaxation & wellness", text: "Yoga, meditation retreats and herbal-garden walks." },
  ]},
  { t: "h", x: "Reference property — Green Cabana Resort, Wayanad" },
  { t: "photoText", photo: "Property, rooms and treatment photography", body: [
    { t: "kv", items: [["Location", "Karimani, Tavinhal (PO), Mananthavady, Wayanad – 670 644"], ["Stay", "Suite, Deluxe and Premium Suite rooms"], ["On site", "In-house dining, yoga, meditation, pool, meetings & events"], ["Ayurveda", "Panchakarma, Kativasthi, Udwarthanam, Shirodhara, lifestyle-disorder, beauty and stress-management treatments"]] },
  ]},
  { t: "h", x: "Nearby" },
  { t: "chips", items: ["Pazhassi Park", "Paingatteri Agraharam", "Priyadarshini Tea Plantation", "Muneeswaran Hills", "Meenmutty Falls", "Palchuram View Point", "Banasura Sagar Dam", "Kurumbalakotta Mala"] },
  { t: "pending", x: "The brochure has a single paragraph on eco tourism; the detail above comes from the old Kairali Wellness Resort listing shared by the client. Please confirm this Wayanad property is the current site, and supply official photos and pricing/booking details." },
]);

add("green-initiatives", "liquid-tree", "Liquid Tree", "drop", "Kairali's newest environmental technology pilot.", [
  { t: "p", x: "Liquid Tree is one of Kairali's newer environmental initiatives, forming part of the Society's expanding portfolio of green-technology projects alongside the Carbon Credit Project." },
  { t: "photo", x: "Liquid Tree inauguration event", ratio: "wide" },
  { t: "pending", x: "Only the name and an inauguration photo caption exist. A short write-up — what it does, where it operates, how it benefits farmers — and photos are needed before this page can carry real detail." },
]);

add("green-initiatives", "bsfl-waste-management", "BSFL / Waste Management", "recycle", "Turning organic waste into value through Black Soldier Fly Larvae technology.", [
  { t: "p", x: "Kairali's Black Soldier Fly Larvae (BSFL) project applies innovative organic waste-management technology — using BSFL to convert agricultural and organic waste into valuable, reusable by-products, reducing waste, supporting soil health and opening a new low-carbon income stream for participating farmers." },
  { t: "cards", cols: 3, items: [
    { icon: "recycle", title: "Waste in", text: "Agricultural and organic waste." },
    { icon: "bug", title: "BSFL at work", text: "Larvae convert waste into biomass." },
    { icon: "sprout", title: "Value out", text: "Reusable by-products for farms." },
  ]},
  { t: "pending", x: "BSFL is now confirmed as a current initiative in the NCUI submission, but scale, farmer participation, output products and timeline are still needed." },
]);

/* ========================= PRODUCTS ========================= */
add("products", "kera-tech", "Kera Tech – Coconut Products", "coconut", "Value-added coconut products, from cooking oil to skincare.", [
  { t: "p", x: "<em>Value-added products from coconut.</em> Kera Tech transforms the coconut into a diverse range of products for food, wellness and everyday living — raising the value of a familiar crop and opening new livelihoods around coconut-based enterprise." },
  { t: "catalog", brand: "kera-tech" },
  { t: "pending", x: "Prices shown are MRP from the internal price list and need finance sign-off before publishing (the list has two suspect purchase-rate entries — Virgin Capsule and Herbal Soap). Purchase rates are deliberately NOT shown on the website." },
  { t: "callout", title: "Order or enquire", x: "For more details please call 0487 – 242 6366 or +91 8078900222.", href: "media/resources-downloads", cta: "Download the brochure" },
]);

add("products", "ecoharvest", "Ecoharvest", "drop", "Plant-based home-care essentials for a cleaner, greener household.", [
  { t: "p", x: "Ecoharvest brings sustainable care into everyday homes — a full range of cleaning and home-care essentials built as practical, eco-conscious alternatives for modern living. Every product supports cleaner, fresher, more sustainable households." },
  { t: "catalog", brand: "ecoharvest" },
  { t: "pending", x: "No sizes, ingredients or prices exist for any Ecoharvest product. Descriptions above were drafted from product names and images on the live site — Kairali to confirm." },
]);

add("products", "bee-craft", "Bee Craft", "hex", "Natural honey and organic wellness products, sourced from Kairali's forest and farming communities.", [
  { t: "p", x: "Bee Craft brings the goodness of natural honey to consumers while creating value from the rich resources of Kairali's farming and forest communities — promoting wholesome products and sustainable forest-based livelihoods." },
  { t: "catalog", brand: "bee-craft" },
  { t: "pending", x: "The live site lists 30+ Bee Craft items (honeys, coffees, fruit crushes, herbal care); all are shown here. Only two honeys have prices/pack sizes. The FMCG list also contains millet mixes, fruit crushes, pickles and herbal/beauty items that may belong under Bee Craft — please confirm categorisation." },
]);

add("products", "green-pad", "Green Pad", "flower", "Herbal sanitary napkins for natural, comfortable menstrual care.", [
  { t: "p", x: "<em>Your Herbal Shield.</em> GreenPad redefines feminine hygiene with a natural, eco-conscious approach. Infused with herbal extracts known for their soothing and antibacterial properties, it provides comfort and protection during menstruation — free from harsh chemicals and synthetic fragrances, gentle on the skin and the planet." },
  { t: "catalog", brand: "green-pad" },
  { t: "docs", title: "Green Pad brochures", files: [["Brochure — English", "Green Pad|Brochure — English"], ["Brochure — Malayalam", "Green Pad|Brochure — Malayalam"]] },
  { t: "h", x: "Nature's care — three herbs" },
  { t: "cards", cols: 3, items: [
    { icon: "flower", title: "Mugwort", text: "Renowned for its calming properties, easing menstrual discomfort and promoting tranquility." },
    { icon: "leaf", title: "Angelica", text: "Valued for centuries for therapeutic benefits, bringing balance to the menstrual experience." },
    { icon: "shield", title: "Fuzi", text: "Celebrated for resilience and strength, providing steadfast protection and comfort." },
  ]},
  { t: "h", x: "GreenPad vs. normal napkins" },
  { t: "table", head: ["", "GreenPad", "Normal napkins"], rows: [
    ["Ingredients", "Mugwort, Angelica, Fuzi", "Synthetic chemicals"],
    ["Comfort", "Natural soothing effect", "May cause irritation"],
    ["Wellness", "Herbal properties promote well-being", "Chemicals may disrupt natural balance"],
    ["Scent", "Natural herbal fragrance", "Artificial fragrance"],
    ["Packaging", "Eco-friendly", "Often non-biodegradable"],
  ]},
  { t: "h", x: "Made with care" },
  { t: "p", x: "Manufactured in a fully enclosed production environment with people–product separation and double shielding forming a sanitary barrier, using fully automatic equipment and on-line testing (stain detection, raw-material detectors)." },
  { t: "kv", items: [["Pack", "10 pads — XXL (350 mm) and XL (280 mm)"], ["Certification", "ISO 9001:2015 facility"], ["Enquiries", "+91 89215 50503 · admin@kairalimscs.com"]] },
  { t: "pending", x: "Pack pricing is not available. Green Pad's brochure uses a different phone number (+91 89215 50503) from the general line — please confirm which to publish." },
]);

add("products", "fmcg-products", "FMCG Products", "basket", "Everyday grocery and household essentials available through Kairali's branch network.", [
  { t: "p", x: "A broad general-store range sold through Kairali branches — flours and podis, pulses, spices, rice, oils, personal care and household cleaning (85 SKUs in the internal price list)." },
  { t: "cards", cols: 3, items: [
    { icon: "wheat", title: "Flours & podis", text: "Aripodi, puttupodi, gothambu podi, idli/dosa podi, rava, atta." },
    { icon: "basket", title: "Pulses & grains", text: "Cherupayar, muthira, kadala, curry parippu, uzhunnuparippu, rice." },
    { icon: "flame", title: "Spices & masalas", text: "Chicken, meat, egg and pork masala; sambar powder; kurumulakupodi." },
    { icon: "drop", title: "Oils & ghee", text: "Gingelly oil, ghee and everyday cooking staples." },
    { icon: "flower", title: "Personal care", text: "Herbal toothpaste, shampoo, hand wash, soaps." },
    { icon: "home", title: "Household", text: "Washing powder, dish wash, detergents." },
  ]},
  { t: "pending", x: "The NCUI submission lists 'FMCG and agricultural products' as a major activity, so this range belongs on the site. Still needed: a curated SKU list, price sign-off, and whether it is an online catalogue, downloadable price list, or in-branch only." },
]);

/* ========================= IMPACT ========================= */
add("impact", "our-impact", "Our Impact", "globe", "How Kairali's initiatives align with the UN Sustainable Development Goals.", [
  { t: "p", x: "Kairali's working pillars map directly onto the UN Sustainable Development Goals." },
  { t: "sdg", items: [
    { n: "2", l: "Zero Hunger", w: "Bee Craft — organic products", c: "#D9A21B" },
    { n: "5", l: "Gender Equality", w: "Green Pad — women's health", c: "#C5392B" },
    { n: "8", l: "Decent Work & Growth", w: "Eco tourism, Integrated Eco Farm", c: "#8B1F41" },
    { n: "12", l: "Responsible Consumption", w: "Kera Tech, Ecoharvest", c: "#B8860B" },
    { n: "13", l: "Climate Action", w: "Carbon Credit Project", c: "#3F7E44" },
  ]},
  { t: "pending", x: "No quantified impact metrics exist — farmers reached, tonnes of CO₂ offset, income uplift, women employed, CSR spend. These would make this page far more persuasive." },
]);

add("impact", "success-stories", "Success Stories", "heart", "Real stories from the farmers and members Kairali works with.", [
  { t: "quote", x: "Kairali Agriculture Multi State Co-operative Society is not just an organization; it's a trusted partner dedicated to the well-being and prosperity of farmers. I highly recommend joining their community!", by: "Mukundan, Farmer" },
  { t: "pending", x: "Only one testimonial exists. 3–5 more named, photographed farmer/member stories would be the highest-value content addition." },
]);

add("impact", "awards-recognition", "Awards & Recognition", "award", "National and international recognition earned by Kairali.", [
  { t: "cards", cols: 3, items: [
    { icon: "award", title: "Jawaharlal Nehru Excellence Award", text: "2026" },
    { icon: "award", title: "Global Indian Switzerland Business Achievement Award", text: "March 2025 — excellence in sustainable carbon-mitigation practices" },
    { icon: "award", title: "Kathir Awards (Kairali TV) — tribute", text: "2025 — presented by actor Sri. Mammootty" },
    { icon: "award", title: "CSR TIMES Award", text: "23 Aug 2024 — 11th National Summit, Raj Bhavan, Goa" },
    { icon: "award", title: "Vayalar Karmasreshta Award", text: "2024 — Vayalar Ramavarma Memorial Foundation" },
    { icon: "award", title: "Kerala Vision Award for Excellence in Climate Change Mitigation", text: "2024" },
    { icon: "award", title: "Best Environmental Activist Award", text: "2024 — presented by Sri. Mohanlal and by the Governor of Kerala" },
    { icon: "award", title: "Indian Achievers’ Award — Best Promising Start-Up", text: "2024 — received by the Carbon Credit Project Head" },
  ]},
  { t: "gallery", items: ["Jawaharlal Nehru Excellence Award 2026", "Award ceremony photographs", "Vayalar Karmasreshta Award", "Best Environmental Activist Award"] },
  { t: "pending", x: "Dates and details are taken from the live About page (checked 27 Sep 2026). The Global Indian Switzerland award is dated March 2025 there, which resolves the earlier 2023/2025 conflict. The live site also mentions an honour presented by Minister Sri. V. N. Vasavan with no name or date — please supply details if it should be listed." },
]);

add("impact", "csr-partnerships", "CSR & Partnerships", "handshake", "The institutions Kairali works alongside to scale its impact, including NCUI and Gold Standard.", [
  { t: "cards", cols: 2, items: [
    { icon: "globe", title: "Gold Standard, Geneva", text: "Engaged with and offered support for Kairali's Carbon Credit Project.", href: "green-initiatives/carbon-credit-project" },
    { icon: "handshake", title: "National Cooperative Union of India", text: "An MoU to strengthen cooperative-led initiatives in sustainable agriculture, carbon reduction and green finance nationwide." },
  ]},
  { t: "h", x: "Our commitment to NCUI" },
  { t: "quote", x: "Kairali Agriculture Multi State Cooperative Society Ltd. values its association with the National Cooperative Union of India (NCUI) and looks forward to strengthening cooperation in the areas of sustainable agriculture, cooperative development, capacity building, green finance, carbon reduction and rural livelihood development.", by: "Kairali Agriculture MSCS Ltd." },
  { t: "p", x: "Kairali's CSR work has also been recognised through the CSR TIMES Award, 2024." },
  { t: "gallery", items: ["NCUI MoU signing", "NCUI — women's cooperative session", "NCUI — herbal processing training", "NCUI — cooperative fair", "NCUI — Ubantu Happiness Centre"] },
  { t: "pending", x: "Only the MoU photo is Kairali's own. The other four are NCUI events supplied by the team — confirm Kairali's involvement and usage rights, or remove." },
]);

/* ========================= MEDIA ========================= */
add("media", "news-events", "News & Events", "news", "Latest updates, launches and milestones from across Kairali.", [
  { t: "news", items: [
    { d: "2026", tag: "Award", title: "Jawaharlal Nehru Excellence Award 2026" },
    { d: "2026", tag: "Branch", title: "Kairali inaugurates its 50th branch" },
    { d: "2026", tag: "Launch", title: "Climate Agro inaugurated" },
    { d: "2026", tag: "Partnership", title: "MoU signed between Kairali and NCUI" },
    { d: "Mar 2025", tag: "Award", title: "Global Indian Switzerland Business Achievement Award 2025", x: "Given to the Chairman for excellence in sustainable carbon-mitigation practices; received in Switzerland on his behalf by Mr. Latheesh V K." },
    { d: "03 Mar 2025", tag: "Event", title: "Climate-change art exhibition by specially-abled artists", x: "Held at the Kerala Lalithakala Academy from 3 to 5 March 2025." },
    { d: "22 Jan 2025", tag: "Event", title: "Chairman co-inaugurates ‘Nammude Office Nammude Kaumudi’", x: "A Kerala Kaumudi initiative to supply newspapers to police stations across Kerala, inaugurated with ADGP Sri. Manoj Abraham." },
    { d: "16 Jan 2025", tag: "Branch", title: "New branch opens at Kadavanthra, Kochi" },
    { d: "04 Jan 2025", tag: "Branch", title: "Renovated Thrissur branch reopens" },
    { d: "2025", tag: "Media", title: "Tribute at the Kathir Awards 2025 (Kairali TV)", x: "The Chairman received a tribute from actor Sri. Mammootty." },
    { d: "18 Dec 2024", tag: "Branch", title: "New branch opens at Valayam, Kozhikode" },
    { d: "2024", tag: "Launch", title: "Liquid Tree inaugurated" },
    { d: "Nov 2024", tag: "Partnership", title: "Meeting with Sri. Dileep Sanghani, Chairman of IFFCO", x: "Carbon Credit Project representatives discussed the project with the IFFCO Chairman." },
    { d: "Nov 2024", tag: "Media", title: "Karshakasree features the Carbon Credit Project", x: "Malayala Manorama’s Karshakasree magazine published an article on the project." },
    { d: "Sep 2024", tag: "Partnership", title: "Discussions with Gold Standard, Geneva", x: "Gold Standard’s International Investment Division offered support for the Carbon Credit Project." },
    { d: "23 Aug 2024", tag: "Award", title: "CSR TIMES award at the 11th National Summit", x: "Presented at Raj Bhavan, Dona Paula, Goa." },
    { d: "2024", tag: "Award", title: "Vayalar Karmasreshta Award 2024", x: "From the Vayalar Ramavarma Memorial Foundation, for contributions to agriculture and community development." },
    { d: "2024", tag: "Award", title: "Kerala Vision Award for Excellence in Climate Change Mitigation 2024" },
    { d: "2024", tag: "Award", title: "Indian Achievers’ Award — Best Promising Start-Up 2024", x: "Received by Mr. Latheesh V K, Project Head of the Carbon Credit Project." },
    { d: "2024", tag: "Partnership", title: "Deesan Farms named model farm for the Carbon Credit Project", x: "The farm at Meenakshipuram, Palakkad, is now a model farm and training centre." },
    { d: "12 Jul 2024", tag: "Branch", title: "New branch opens at Kattoor, Thrissur" },
    { d: "27 May 2024", tag: "Branch", title: "New branch opens at Wadakkanchery, Thrissur" },
    { d: "18 May 2024", tag: "Event", title: "Business conference in Thrissur" },
    { d: "02 May 2024", tag: "Branch", title: "New branch opens at Kollengode, Palakkad" },
    { d: "29 Apr 2024", tag: "Branch", title: "New branch opens at Karakurissi, Palakkad" },
    { d: "06 Apr 2024", tag: "Branch", title: "New branch opens at Meppayur, Kozhikode" },
    { d: "2024", tag: "Award", title: "Best Environmental Activist Award", x: "Presented by Sri. Mohanlal; the Governor of Kerala, Sri. Arif Mohammad Khan, also presented the award to the Chairman." },
    { d: "21 Mar 2024", tag: "Media", title: "Press conference on the Carbon Credit Project" },
    { d: "12 Mar 2024", tag: "Branch", title: "New branch opens at Kalpetta, Wayanad" },
    { d: "11 Mar 2024", tag: "Branch", title: "New branch opens at Sulthan Bathery, Wayanad" },
    { d: "02 Mar 2024", tag: "Launch", title: "Green Pad herbal sanitary napkins launched" },
    { d: "29 Feb 2024", tag: "Branch", title: "New branch opens at Chittur, Palakkad" },
    { d: "28 Feb 2024", tag: "Branch", title: "New branch opens at Arakkuparamba, Malappuram" },
    { d: "17 Aug 2023", tag: "Event", title: "First Annual Day celebration, Thrissur" }
  ]},
  { t: "pending", x: "Migrated from the live About page (checked 27 Sep 2026) and rewritten in one date format (DD Mon YYYY; month or year only where the source gives no day). Exact days are missing for the 2026 items and several awards. The NCUI MoU photo on the live site is dated 18 Nov 2025 — please confirm whether the MoU was signed in 2025 or 2026. The live feed also has a bare ‘07-05-2024’ entry with no text, which has been left out." },
]);

add("media", "photo-gallery", "Photo Gallery", "camera", "Moments from our events, branches and community.", [
  { t: "h", x: "From Kairali" },
  { t: "gallery", items: ["50th branch inauguration", "Climate Agro inauguration", "NCUI MoU signing", "Gold Standard, Geneva", "Vayalar Karmasreshta Award", "Liquid Tree inauguration", "50th branch — lamp lighting", "Jawaharlal Nehru Excellence Award 2026", "Meeting with IFFCO Chairman", "Best Environmental Activist Award", "Gold Standard, Geneva (2)", "Kairali TV — Snehadharam"] },
  { t: "h", x: "With NCUI — the wider cooperative movement" },
  { t: "gallery", items: ["NCUI — herbal processing training", "NCUI — herbal sorting", "NCUI — women's cooperative session", "NCUI — cooperative fair", "NCUI — Ubantu Happiness Centre", "NCUI — gathering", "NCUI — FPO group photo", "NCUI — herbal tea training", "NCUI — product stall", "NCUI — felicitation"] },
  { t: "pending", x: "The NCUI photos were supplied by the internship team and show NCUI events in Uttar Pradesh and Uttarakhand (Nov 2025 – Mar 2026). Confirm whether Kairali took part and whether NCUI permits their use before publishing." },
  { t: "p", x: "Photos will be organised by category: Awards & Recognition · Events & Inaugurations · Partnerships · Community & Farmers." },
]);

add("media", "video-gallery", "Video Gallery", "play", "Kairali TV and other video features.", [
  { t: "cards", cols: 2, items: [
    { icon: "play", title: "Kairali TV — Snehadharam", text: "" },
    { icon: "play", title: "Carbon Credit Project videos", text: "" },
  ]},
  { t: "pending", x: "No video list, links or embed sources were found — needed from the media team." },
]);

add("media", "resources-downloads", "Resources & Downloads", "download", "Brochures, syllabi and other downloadable materials, all in one place.", [
  { t: "downloads", groups: [
    { title: "Carbon Credit Project", files: ["Brochure — English", "Brochure — Malayalam", "Brochure — Tamil", "Syllabus — English", "Syllabus — Malayalam", "Booklet — Malayalam", "Notice — Malayalam"] },
    { title: "Eco / Farm Tourism", files: ["Brochure"] },
    { title: "Green Pad", files: ["Brochure — English", "Brochure — Malayalam"] },
    { title: "Kera Tech", files: ["Brochure / Flyer"] },
    { title: "Company profile", files: ["Kairali Agriculture Cooperative Brochure"] },
  ]},
  { t: "pending", x: "This covers every download confirmed so far. Do Ecoharvest, Bee Craft, FMCG, Integrated Eco Farm, Liquid Tree or BSFL have brochures to add?" },
]);

/* ========================= MEMBERSHIP ========================= */
add("membership", "become-a-member", "Become a Member", "users", "How to join Kairali as a member.", [
  { t: "p", x: "Join Kairali Agriculture Multi State Co-operative Society Ltd. and become part of a growing community of farmers and rural entrepreneurs working towards a sustainable, prosperous future. Whether you are a farmer seeking support and resources, or someone who wants to contribute to sustainable agriculture, you are welcome." },
  { t: "steps", items: [
    { h: "Visit your nearest branch", x: "Find one of our 55 branches across Kerala and Tamil Nadu." },
    { h: "Speak to our team", x: "Learn about contribution schemes, benefits and services." },
    { h: "Complete enrolment", x: "Submit the required details to become a member." },
  ]},
  { t: "callout", title: "Find your nearest branch", x: "Or call the head office on 0487 – 242 6366 / +91 8078900222.", href: "contact/branch-network", cta: "Branch network" },
  { t: "pending", x: "No eligibility criteria, membership fee, required documents (KYC) or online application process are available. The three steps above are a placeholder flow — please confirm the real process." },
]);

add("membership", "member-benefits", "Member Benefits", "heart", "The financial, insurance and cooperative benefits available to members.", [
  { t: "cards", cols: 2, items: [
    { icon: "shield", title: "Insurance & social security", text: "Protection for farmer-members and their families against unforeseen risk — mutual benefit and collective security in practice." },
    { icon: "coins", title: "Contribution schemes", text: "Fixed, recurring and monthly profit-share schemes.", href: "membership/contribution-schemes" },
    { icon: "book", title: "Training & capacity building", text: "Skills and awareness programmes.", href: "our-work/training-capacity-building" },
    { icon: "sun", title: "Green initiatives", text: "Opportunities such as the Carbon Credit Project.", href: "green-initiatives/index" },
  ]},
  { t: "pending", x: "No insurance products, providers, coverage amounts or premiums are available. Needed from the finance/insurance team." },
]);

add("membership", "member-services", "Member Services", "hand", "The specific services members can access through Kairali.", [
  { t: "p", x: "As a Kairali member, you can access:" },
  { t: "ul", items: ["Savings and capital-growth support through the contribution schemes", "Insurance and social security cover", "Training, awareness and capacity-building sessions", "Market-linkage and value-addition support through Kairali's product lines and cooperative network"] },
]);

add("membership", "contribution-schemes", "Contribution Schemes", "coins", "Savings and profit-share schemes designed for farmer-members.", [
  { t: "p", x: "Kairali offers three contribution schemes to its members. Each is explained below — use the buttons to jump straight to one." },
  { t: "schemes", items: [
    { id: "recurring", icon: "calendar", title: "Recurring Contribution", for: "For members who want to save a small amount every month.", text: "You contribute a fixed amount at regular intervals. You choose the tenure and the monthly amount that suits you.", points: ["Small, regular monthly contributions", "Choose your own tenure", "Choose your minimum monthly amount"] },
    { id: "fixed", icon: "coins", title: "Fixed Contribution", for: "For members who want to set aside a lump sum for a set period.", text: "You contribute a fixed amount for a fixed period and receive the return agreed at the start.", points: ["One contribution for a set period", "Return agreed at the start", "Often chosen by senior members planning for retirement"] },
    { id: "profit-share", icon: "sun", title: "Monthly Profit Share", for: "For shareholders who want a regular monthly income.", text: "Shareholders receive a share of the society’s profit every month, at the rate set for the scheme.", points: ["Monthly income for shareholders", "Linked to the society’s profit", "Rate set by the society"] },
  ]},
  { t: "pending", x: "No rates, minimum amounts or tenures are available for any scheme; all figures must come from the finance team. The live Services page describes these schemes as ‘safe’, with ‘assured return’, the ‘best rate within the industry’, and calls them ‘recurring deposits’. That wording has been removed here and should be reviewed by Kairali’s legal/compliance adviser before any scheme text is published, as deposit-style promises by cooperatives are regulated." },
]);

add("membership", "member-faqs", "Member FAQs", "help", "Answers to common questions about membership.", [
  { t: "faq", items: [
    { q: "What is Kairali Agriculture MSCS Ltd.?", a: "A multi-state cooperative society registered under the Ministry of Cooperation, Government of India, working to empower farmers and promote sustainable agriculture." },
    { q: "What contribution schemes are available?", a: "Fixed Contribution, Recurring Contribution and Monthly Profit Share." },
    { q: "Does Kairali offer insurance to members?", a: "Yes — insurance and social security initiatives are part of Kairali's member-welfare benefits." },
    { q: "Where can I find my nearest branch?", a: "See the Branch Network page for all 55 branches across Kerala and Tamil Nadu." },
    { q: "Who is eligible to become a member, and how do I apply?", a: "<span class=\"pending-inline\">Answer pending from Kairali.</span> Please contact your nearest branch." },
  ]},
  { t: "pending", x: "Eligibility, fees and application process are not available in the source material — the last FAQ cannot be answered accurately until Kairali provides them." },
]);

/* ========================= CONTACT ========================= */
add("contact", "head-office", "Head Office", "pin", "Our registered head office address and contact details.", [
  { t: "kv", items: [["Society", "Kairali Agriculture Multi State Co-Operative Society Ltd."], ["Regd. No.", "MSCS/CR/1346/2022"], ["Address", "Kovilakam Tower, Warriam Lane, Thekkemadom Road, Thrissur – 680001, Kerala, India"], ["Phone", "0487 – 242 6366 · +91 8078900222"], ["Email", "info@kairalimscs.com"]] },
  { t: "photo", x: "Map — Thrissur head office", ratio: "wide" },
  { t: "pending", x: "Three head-office emails appear across documents: info@ (live Contact page), thrissur@ (brochure back cover) and admin@ (product brochures). Please pick one primary address." },
]);
add("contact", "branch-network", "Branch Network", "map", "Find your nearest Kairali branch office.", [{ t: "branches" }]);
add("contact", "contact-enquiry", "Contact / Enquiry", "mail", "Send Kairali a message directly.", [{ t: "contactform" }]);

module.exports = { sections, pages };
