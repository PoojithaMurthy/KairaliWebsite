// Kairali product catalogue — drives the Products pages and the basket.
// Images: hotlinked from Kairali's live site (kairalimscs.com/wp-content/uploads). Replace with local copies before launch.
// Prices: MRP from the internal price list (pending finance sign-off). `mrp` is the single number used for basket totals;
// items with a range or no price have mrp: null and are marked "price confirmed on enquiry" in the basket.
// Descriptions marked `draft: true` were written from the product name only and need Kairali sign-off.

const U = "https://kairalimscs.com/wp-content/uploads/";

const brands = {
  "kera-tech": { label: "Kera Tech", page: "kera-tech" },
  ecoharvest: { label: "Ecoharvest", page: "ecoharvest" },
  "bee-craft": { label: "Bee Craft", page: "bee-craft" },
  "green-pad": { label: "Green Pad", page: "green-pad" },
};

const P = (brand, id, name, cat, desc, price, mrp, size, img, draft) => ({ brand, id, name, cat, desc, price, mrp, size, img, draft: !!draft });

const products = [
  /* ---------- Kera Tech — coconut ---------- */
  P("kera-tech", "virgin-plus-oil", "Virgin Plus Coconut Oil", "Oils", "Extracted from fresh coconut milk through a chemical-free process, so it keeps its natural vitamins, minerals and antioxidants. Mild flavour for everyday cooking and baby food.", "₹98 – ₹760", null, "Multiple pack sizes", U + "2023/05/Virgin-Plus-300x300.jpg"),
  P("kera-tech", "premium-oil", "Premium Coconut Oil", "Oils", "Cold-pressed from handpicked coconuts and rich in MCTs. Works for cooking and baking as well as skin and hair care.", "₹248 – ₹485", null, "Multiple pack sizes", U + "2024/03/COCO-PREMIUM-300x300.png"),
  P("kera-tech", "coconut-chips", "Coconut Chips", "Snacks", "Thin slices of tender coconut, toasted to bring out their natural sweetness. A simple, crunchy snack.", "₹40", 40, "20 g", U + "2023/05/virgin-plus-tender-coconut-chips-300x300.jpeg"),
  P("kera-tech", "dc-powder", "Desiccated Coconut Powder", "Kitchen", "100% pure, finely grated dried coconut with no additives. Use it in sweets, bakes, chutneys and curries.", "₹63 – ₹120", null, "Multiple pack sizes", U + "2023/05/virgin-plus-dc-powder-300x300.jpeg"),
  P("kera-tech", "coconut-sugar", "Coconut Sugar Powder", "Kitchen", "An unrefined sweetener made from coconut palm sap, with a lower glycemic index than white sugar. Swap it in for tea, coffee and baking.", "₹155", 155, "150 g", U + "2023/05/Sugar-Powder-300x300.jpg"),
  P("kera-tech", "milk-powder", "Coconut Milk Powder", "Kitchen", "Dissolves quickly in warm water to give creamy coconut milk. Handy for curries, soups, payasam and desserts.", "₹145", 145, "Standard pack", U + "2024/03/COCO-MIL-POWDER-300x300.png"),
  P("kera-tech", "virgin-capsules", "Virgin Capsules", "Wellness", "Soft-gel capsules filled with pure, unrefined virgin coconut oil — an easy way to take it daily.", "₹295", 295, "Bottle", U + "2023/05/virgin-plus-immunity-booster-capsules-300x300.jpeg"),
  P("kera-tech", "massage-oil", "Body Massage Oil", "Personal care", "Cold-pressed coconut oil for massage. Hydrates and softens all skin types.", "", null, "", U + "2023/05/virgin-plus-massage-oil--300x300.jpeg"),
  P("kera-tech", "hair-cream", "Natural Hair Cream", "Personal care", "Made with botanical oils, vitamins and proteins to nourish hair. Comes in Lotus and Apple variants.", "₹300", 300, "50 g", U + "2023/06/Hair-Cream-e1685962363453-300x300.png"),
  P("kera-tech", "herbal-soap", "Ayurveda Herbal Soap", "Personal care", "A gentle bathing bar with neem, turmeric and sandalwood, finished with pure essential oils.", "₹65", 65, "75 g", U + "2023/05/Soap-300x300.jpg"),
  P("kera-tech", "mouth-freshener", "Mouth Freshener", "Wellness", "A blend of aromatic seeds and herbs for after meals. Available in Mint and Orange.", "", null, "", U + "2023/05/virgin-plus-mouth-freshener-300x300.jpeg"),
  P("kera-tech", "chammanthi-podi", "Coconut Chammanthi Podi", "Kitchen", "Kerala-style roasted coconut chammanthi podi, with a coconut-and-prawns version too. Mix with rice and a spoon of oil.", "₹95 – ₹115", null, "Multiple variants", U + "2023/05/Chamanthi-Podi-300x300.jpg"),

  /* ---------- Ecoharvest — home care ---------- */
  P("ecoharvest", "floor-cleaner", "Floor Cleaner", "Cleaning", "A plant-based floor cleaner from the Ecoharvest range, for tiles, stone and everyday mopping.", "", null, "", U + "2024/03/6-1-300x300.jpg", true),
  P("ecoharvest", "toilet-cleaner", "Toilet Cleaner – Foaming", "Cleaning", "A foaming toilet cleaner that clings to the bowl so it can work longer between scrubs.", "", null, "", U + "2024/03/7-1-300x300.jpg", true),
  P("ecoharvest", "laundry-detergent", "Laundry Detergent", "Laundry", "An everyday liquid detergent for machine and hand wash, part of Kairali's plant-based home-care line.", "", null, "", U + "2024/03/5-1-300x300.jpg", true),
  P("ecoharvest", "all-purpose", "All Purpose Cleaner – Foaming", "Cleaning", "One foaming spray for kitchen counters, tables and other washable surfaces around the house.", "", null, "", U + "2024/03/8-1-300x300.jpg", true),
  P("ecoharvest", "dishwash-gel", "Dishwash Gel", "Kitchen", "A dishwash gel for pots, pans and daily utensils. A little goes a long way on a wet sponge.", "", null, "", U + "2024/03/1-2-scaled.jpg", true),
  P("ecoharvest", "stain-remover", "Stain Remover for Clothes", "Laundry", "Apply to the stain before washing to help lift everyday marks from clothes.", "", null, "", U + "2024/03/2-1-scaled.jpg", true),
  P("ecoharvest", "mosquito-repellent", "Mosquito Repellent", "Home", "A home mosquito repellent from the Ecoharvest range, sold on Kairali's site as “Mosquito Defence – Earthy Elegance”.", "", null, "", U + "2024/03/10.jpeg", true),
  P("ecoharvest", "fabric-refresher", "Fabric Refresher", "Laundry", "A spray to freshen curtains, sofas and clothes between washes.", "", null, "", U + "2024/03/12.jpeg", true),
  P("ecoharvest", "air-freshener", "Air Freshener", "Home", "A room spray to keep living spaces smelling fresh.", "", null, "", U + "2024/03/9.jpeg", true),

  /* ---------- Bee Craft — honey & organic ---------- */
  P("bee-craft", "wayanadan-honey", "Wayanadan Forest Honey", "Honey", "Forest honey sourced from Wayanad's forest and farming communities.", "₹180", 180, "250 g", U + "2024/03/Bee8.png"),
  P("bee-craft", "natural-wayanadan-honey", "Natural Wayanadan Forest Honey", "Honey", "Raw natural honey from Wayanad's forest communities.", "", null, "", U + "2024/03/Bee9.png", true),
  P("bee-craft", "black-forest-honey-250", "Black Forest Honey", "Honey", "A dark, rich forest honey with a deeper taste than regular honey.", "₹260", 260, "250 g", U + "2024/03/Bee6.png"),
  P("bee-craft", "black-forest-honey-500", "Black Forest Honey (500 g)", "Honey", "The same dark, rich forest honey in a larger family pack.", "", null, "500 g", U + "2024/03/Bee5.png"),
  P("bee-craft", "amla-honey", "Amla Honey", "Honey", "Honey with Indian gooseberry (amla) — tangy and sweet.", "", null, "", U + "2024/03/Bee31.png", true),
  P("bee-craft", "dry-fruits-honey", "Dry Fruits Honey", "Honey", "Honey packed with dry fruits. Eat it by the spoon or spread it on toast.", "", null, "", U + "2024/03/Bee7.png", true),
  P("bee-craft", "ajwain-honey", "Ajwain Honey", "Honey", "Ajwain (carom) honey with a warm, herbal flavour.", "", null, "250 g / 500 g", U + "2024/03/Bee3.png", true),
  P("bee-craft", "wayanadan-coffee", "Wayanadan Coffee", "Coffee & tea", "Coffee from Wayanad's hill farms for a strong morning cup.", "", null, "", U + "2024/03/Bee24.png", true),
  P("bee-craft", "masala-coffee", "Masala Coffee", "Coffee & tea", "Coffee blended with warming spices.", "", null, "", U + "2024/03/Bee23.png", true),
  P("bee-craft", "ginger-coffee", "Ginger Coffee", "Coffee & tea", "Coffee with a kick of ginger.", "", null, "", U + "2024/03/Bee21.png", true),
  P("bee-craft", "chukku-kappi", "Chukku Kappi", "Coffee & tea", "Kerala's traditional dry-ginger (chukku) coffee.", "", null, "", U + "2024/03/Bee18.png", true),
  P("bee-craft", "pure-coffee", "Pure Coffee", "Coffee & tea", "Plain ground coffee for a clean, simple cup.", "", null, "", U + "2024/03/Bee22.png", true),
  P("bee-craft", "coffee-bean-roast", "Coffee Bean Roast", "Coffee & tea", "Roasted whole coffee beans for grinding fresh at home.", "", null, "", U + "2024/03/Bee19.png", true),
  P("bee-craft", "green-tea", "Green Tea", "Coffee & tea", "Light, everyday green tea.", "", null, "", U + "2024/03/Bee20.png", true),
  P("bee-craft", "mango-crush", "Alphonso Mango Crush", "Fruit crushes", "Alphonso mango crush. Mix with chilled water or milk for a quick drink.", "", null, "", U + "2024/03/Bee10.png", true),
  P("bee-craft", "passion-crush", "Passion Fruit Crush", "Fruit crushes", "Passion fruit crush — dilute with cold water for a tangy drink.", "", null, "", U + "2024/03/Bee15.png", true),
  P("bee-craft", "pineapple-crush", "Pineapple Crush", "Fruit crushes", "Pineapple crush for juices, mocktails and desserts.", "", null, "", U + "2024/03/Bee14.png", true),
  P("bee-craft", "guava-crush", "Pink Guava Crush", "Fruit crushes", "Pink guava crush for a sweet, fragrant drink.", "", null, "", U + "2024/03/Bee16.png", true),
  P("bee-craft", "jamun-crush", "Jamun Crush", "Fruit crushes", "Jamun (Indian blackberry) crush.", "", null, "", U + "2024/03/Bee12.png", true),
  P("bee-craft", "strawberry-crush", "Strawberry Crush", "Fruit crushes", "Strawberry crush for drinks and milkshakes.", "", null, "", U + "2024/03/Bee17.png", true),
  P("bee-craft", "orange-crush", "Orange Crush", "Fruit crushes", "Orange crush for a quick fruit drink.", "", null, "", U + "2024/03/Bee13.png", true),
  P("bee-craft", "grape-crush", "Grape Crush", "Fruit crushes", "Grape crush for drinks and desserts.", "", null, "", U + "2024/03/Bee11.png", true),
  P("bee-craft", "aloe-gel", "Aloe Vera Gel", "Herbal care", "Aloe vera gel for skin and hair.", "", null, "100 g / 200 g", U + "2024/03/Bee26.png", true),
  P("bee-craft", "rose-water", "Natural Rose Water", "Herbal care", "Rose water for use as a toner or in face packs.", "", null, "", U + "2024/03/Bee28.png", true),
  P("bee-craft", "kasthuri-manjal", "Kasthuri Manjal", "Herbal care", "Wild turmeric powder, used traditionally in face packs.", "", null, "", U + "2024/03/Bee32.png", true),
  P("bee-craft", "red-sandal", "Red Sandal", "Herbal care", "Red sandalwood powder for traditional face packs.", "", null, "", U + "2024/03/Bee34.png", true),
  P("bee-craft", "multani-mitti", "Multani Mitti", "Herbal care", "Fuller's earth clay for face packs.", "", null, "", U + "2024/03/Bee33.png", true),
  P("bee-craft", "amla-powder", "Amla Powder", "Herbal care", "Dried Indian gooseberry powder, used in hair packs.", "", null, "", U + "2024/03/Bee29.png", true),
  P("bee-craft", "indigo-powder", "Indigo Powder", "Herbal care", "Indigo leaf powder, used as a natural hair colour.", "", null, "", U + "2024/03/Bee27.png", true),
  P("bee-craft", "forest-oil", "Forest Oil", "Herbal care", "An oil from Bee Craft's forest-sourced range.", "", null, "", U + "2024/03/Bee30.png", true),

  /* ---------- Green Pad ---------- */
  P("green-pad", "green-pad", "Green Pad Herbal Sanitary Napkins", "Menstrual care", "Herbal sanitary napkins with mugwort, angelica and fuzi — free from harsh chemicals and synthetic fragrance. Each pack has 10 pads in XXL (350 mm) and XL (280 mm).", "", null, "10 pads", U + "2024/03/Web.-Green-Pad-022-300x169.png"),
];

module.exports = { brands, products };
