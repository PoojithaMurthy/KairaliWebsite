@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Opening the site directly instead...
  start "" "site\index.html"
  pause
  exit /b
)
if not exist "src\img\kairali" (
  echo Saving Kairali's photos locally ^(first run only^)...
  node build.js >nul
  node fetch-images.js
)
node build.js
start "" http://localhost:5173
echo.
echo Kairali preview running at http://localhost:5173  - close this window to stop.
node serve.js 5173
