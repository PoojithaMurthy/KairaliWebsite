# Kairali — sample website (draft v0.5)

**v0.5:** fixes from the verified audit of the live site — filterable News & Events (34 items, one date format); one section per contribution scheme with direct links and neutral wording; brochures on their own project pages; real social links; self-updating copyright; one spelling of the Chairman’s name; captioned registration certificate; corrected awards and timeline.

**v0.4:** official Kairali logo + favicon from kairalimscs.com (drawn mark kept as fallback) · "Full details" product dialog with Kairali's own description, highlights, uses, large image, quantity + Add to basket, and a link back to the product on kairalimscs.com (`content/product-details.js`) · 9 real brochure PDFs linked in Resources & Downloads.


**v0.3 homepage (follows the approved mockup):** full-width photo slider (3 slides, 01/03 counter, progress bars, pause, arrows, swipe, arrow keys; slow zoom; stops for reduced-motion users) · key-areas strip · about collage + reach tiles (verified figures only) · "Our work in focus" scrollable image cards that widen on hover · scrollable product rail with Add to basket · "Stories from the ground" band with video link + scrollable thumbnails · moving photo strip of Kairali milestones (pauses on hover/focus, Pause button). Field photos in the slider/cards are temporary Wikimedia Commons images (credited) with Kairali fallbacks — replace with Kairali's own field photography.


**v0.2 changes:** product catalogue (52 items) with descriptions, images, prices and an order-enquiry basket (sends to WhatsApp/email, no online payment); shop page with range filters and search; warmer type (Nunito + Fraunces with italic/bold); real photography (Kairali's own, plus team-supplied NCUI event photos flagged in Review mode); gallery lightbox; contact map; mobile overflow, logo and header fixes. See START-HERE.txt to view.

`npm run images` downloads Kairali's photos into `src/img/kairali` so the site no longer hotlinks them.

Static, dependency-free site (plain HTML/CSS/JS) built from the Content Document. **Not hosted** — runs locally only.

## Run it

Requires Node.js (any recent version). No `npm install` needed.

```bash
cd kairali-website
node build.js        # regenerates ./site from content/
node serve.js 5173   # then open http://localhost:5173
# or: npm start
```

You can also open `site/index.html` directly in a browser (all links are relative).

## Structure

```
kairali-website/
├─ content/
│  ├─ site.js        ← navigation + every page's copy (edit content here)
│  └─ branches.js    ← 55-branch directory (50 Kerala, 5 Tamil Nadu)
├─ src/
│  ├─ style.css      ← design system (palette, arch-frame motif, mega-menu, responsive)
│  └─ main.js        ← mobile menu, stat counters, branch filters, review mode
├─ build.js          ← generator: layout, icons, block renderers, home page
├─ serve.js          ← tiny static server
└─ site/             ← generated output (44 pages) — this is the website
```

Navigation follows the finalised tab structure: Home · About Us · Our Work · Green Initiatives · Products · Impact · Media & Resources · Membership · Contact. Menus, breadcrumbs, side-navs, footer and one-liners are all generated from `content/site.js`, so renaming a page there updates it everywhere.

## Editing content

Each page is `add(section, slug, label, icon, one-liner, blocks)`. Block types: `p`, `h`, `ul`, `cards`, `products`, `table`, `timeline`, `faq`, `steps`, `sdg`, `news`, `gallery`, `downloads`, `quote`, `callout`, `kv`, `chips`, `photo`, `photoText`, `pending`, `branches`, `contactform`. After editing, run `node build.js` and refresh.

## Review mode

Anything Kairali still has to confirm is written as a `pending` block. They are hidden by default; click **Review mode** (bottom-left) or add `?review=1` to any URL to show them in yellow. These correspond to the yellow `[NEEDS INPUT]` flags in the Content Document.

## Placeholders to replace before launch

- **Photography** — all images are placeholder frames (`ph()` in `build.js`); swap for `<img>` tags when photos are supplied.
- **Download links** — the Resources & Downloads page uses `href="#"`; attach the real PDFs.
- **Enquiry form** — front-end only; needs a backend/email handler.
- **Prices** — MRP shown from the internal price list, pending finance sign-off. Purchase rates are deliberately not published.
- **Fonts** — Fraunces + Nunito Sans load from Google Fonts (falls back to Georgia / system UI when offline).

## Design notes

Reference sites (ASA, AKRSP, PRADAN, Gram Vikas, WOTR) informed the *structure* — a stats strip, thematic "what we do" cards, programme/initiative pages with side navigation, story-led impact, news and resources hubs, and a branch/network directory — but the look is original: an earthy organic palette (forest, moss, paper, clay, turmeric), serif display type, arch-shaped image frames and leaf motifs, and a mega-menu that shows each sub-page's one-liner.
